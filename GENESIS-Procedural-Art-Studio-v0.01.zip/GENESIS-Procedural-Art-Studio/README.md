# GENESIS — Procedural Art Studio v0.01

**Application ID:** `com.genesis.proceduralart`  
**Version name:** `0.01`  
**Version code:** `1`  
**Release:** v0.01 — Initial Release  

Offline-first native Android procedural art studio. Artwork is generated locally from mathematical algorithms, not from stock images or cloud AI.

## What is implemented in v0.01

- Native Kotlin + Jetpack Compose application
- Dark monochrome AMOLED-friendly UI
- Bottom navigation: Home · Explore · Create · Gallery · Settings
- 11 real CPU procedural generators:
  - Concentric Circles, Radial Mandala, Grid Lines, Recursive Subdivision
  - Mandelbrot Set, Julia Set, Sierpiński Triangle, Recursive Tree
  - Value Noise, Wave Interference, Stipple Field
- Deterministic seeded randomness
- Interactive editor with parameter sliders, seed control, randomize
- CPU renderer (background coroutine)
- About / Settings screen showing version v0.01
- Unit tests for seeded random and generator registry
- Gradle Kotlin DSL, Compose BOM, Room/DataStore dependencies declared
- GitHub Actions workflow that builds a debug APK

## Deferred / not fully implemented in v0.01

- OpenGL ES / GLSL GPU paths (CPU is the reliable baseline)
- Full multi-layer composition UI and blend modes
- Room-backed project gallery with thumbnails (structure present, UI is placeholder)
- `.genesisart` project archive import/export validation
- PNG/JPEG export pipeline UI
- Advanced presets library
- Instrumentation / UI tests on device
- Animation export, vector SVG, sophisticated simulations

A smaller set of fully working algorithms was preferred over a large library of incomplete placeholders.

## Toolchain (target)

| Component              | Version        |
|------------------------|----------------|
| Android Gradle Plugin  | 8.5.2          |
| Gradle                 | 8.7            |
| Kotlin                 | 1.9.24         |
| Compose BOM            | 2024.06.00     |
| compileSdk / targetSdk | 34             |
| minSdk                 | 26             |
| JDK                    | 17             |

## Open in Android Studio

1. Install Android Studio (Hedgehog or newer recommended).
2. Unzip `GENESIS-Procedural-Art-Studio-v0.01.zip`.
3. Open the extracted folder as an Android Studio project.
4. Let Gradle sync. Accept any SDK license prompts.
5. Run on an emulator or device (API 26+).

## Build from command line

```bash
cd GENESIS-Procedural-Art-Studio
./gradlew assembleDebug
```

APK will be at `app/build/outputs/apk/debug/`.

## GitHub Actions (from an Android phone or any browser)

1. Create a new GitHub repository.
2. Upload the contents of the project (or the ZIP + workflow).
3. Recommended repository layout:

```
your-repo/
├── GENESIS-Procedural-Art-Studio/   # or extract the ZIP here
│   ├── app/
│   ├── gradle/
│   ├── gradlew
│   ├── ...
└── .github/
    └── workflows/
        └── build-apk.yml
```

4. In the Actions tab, run the **Build GENESIS Debug APK** workflow (workflow_dispatch or push).
5. Download the artifact named **GENESIS-v0.01-debug-APK**.

The workflow uses `actions/checkout@v4`, sets up JDK 17, runs unit tests, and executes `assembleDebug`.

## Install the APK

1. Download the artifact ZIP from Actions.
2. Extract the `.apk`.
3. On your Android device: enable “Install unknown apps” for the file manager or browser.
4. Open the APK and install.
5. Launch **GENESIS**.

## Privacy

No accounts, no telemetry, no advertising SDKs, no required internet permission for core features. Project data stays on device.

## Known limitations

- GPU rendering path is not active; all generators use the CPU renderer.
- Gallery screen is a placeholder; projects are not yet persisted through a full UI flow.
- Export and project archive features are declared in architecture but not wired to the UI in this release.
- Preview resolution is fixed at 512×512 for responsiveness; higher resolutions will be available when the export path is completed.
- Some complex generators (deep Mandelbrot) can take noticeable time on low-end devices; work runs off the main thread.

## License notices

This is an initial educational / experimental release. Third-party libraries (AndroidX, Kotlin, etc.) retain their own licenses. Add a full `NOTICE` file before any public distribution.

---

**GENESIS v0.01** — built for offline procedural creation.
