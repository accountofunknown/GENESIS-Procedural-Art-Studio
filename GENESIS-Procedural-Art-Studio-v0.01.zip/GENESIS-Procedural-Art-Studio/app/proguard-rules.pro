# GENESIS v0.01 - keep for future minify
-keepclassmembers class * {
    @kotlinx.serialization.Serializable <fields>;
}
