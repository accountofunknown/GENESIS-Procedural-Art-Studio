package com.genesis.proceduralart

import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class GeneratorRegistryTest {
    @Before
    fun setup() {
        GeneratorBootstrap.ensureInitialized()
    }

    @Test
    fun registryContainsGenerators() {
        val all = GeneratorRegistry.all()
        assertTrue(all.size >= 36)
        assertNotNull(GeneratorRegistry.get("mandelbrot"))
        assertNotNull(GeneratorRegistry.get("julia"))
        assertNotNull(GeneratorRegistry.get("sierpinski"))
        assertNotNull(GeneratorRegistry.get("clifford"))
        assertNotNull(GeneratorRegistry.get("reaction_diffusion"))
        assertNotNull(GeneratorRegistry.get("particle_field"))
    }

    @Test
    fun defaultParametersExist() {
        for (g in GeneratorRegistry.all()) {
            val p = g.defaultParameters()
            assertTrue(p.values.isNotEmpty() || g.parameterSchema.isEmpty())
        }
    }
}
