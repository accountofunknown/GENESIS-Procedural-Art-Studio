package com.genesis.proceduralart

import com.genesis.proceduralart.core.random.SeededRandom
import org.junit.Assert.*
import org.junit.Test

class SeededRandomTest {
    @Test
    fun sameSeedProducesSameSequence() {
        val a = SeededRandom(42L)
        val b = SeededRandom(42L)
        repeat(50) {
            assertEquals(a.nextDouble(), b.nextDouble(), 0.0)
            assertEquals(a.nextInt(1000), b.nextInt(1000))
        }
    }

    @Test
    fun differentSeedsDiffer() {
        val a = SeededRandom(1L)
        val b = SeededRandom(2L)
        assertNotEquals(a.nextLong(), b.nextLong())
    }
}
