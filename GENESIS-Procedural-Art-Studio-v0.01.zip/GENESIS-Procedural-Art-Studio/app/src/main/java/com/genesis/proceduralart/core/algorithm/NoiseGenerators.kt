package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/** Simple value-noise based on seed (not full Perlin, but deterministic and usable). */
class ValueNoiseGenerator : ProceduralGenerator {
    override val id = "value_noise"
    override val name = "Value Noise"
    override val description = "Smooth value noise field"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("scale", "Scale", ParameterType.FLOAT, "0.02", 0.005f, 0.1f, 0.001f),
        ParameterDef("octaves", "Octaves", ParameterType.INT, "4", 1f, 6f, 1f),
        ParameterDef("persistence", "Persistence", ParameterType.FLOAT, "0.5", 0.2f, 0.8f, 0.05f)
    )

    private fun hash(x: Int, y: Int, seed: Long): Float {
        var n = x * 374761393 + y * 668265263 + seed.toInt()
        n = (n xor (n ushr 13)) * 1274126177
        n = n xor (n ushr 16)
        return (n and 0x7fffffff) / 2147483647f
    }

    private fun smoothNoise(x: Float, y: Float, seed: Long): Float {
        val x0 = floor(x).toInt()
        val y0 = floor(y).toInt()
        val fx = x - x0
        val fy = y - y0
        val sx = fx * fx * (3 - 2 * fx)
        val sy = fy * fy * (3 - 2 * fy)
        val n00 = hash(x0, y0, seed)
        val n10 = hash(x0 + 1, y0, seed)
        val n01 = hash(x0, y0 + 1, seed)
        val n11 = hash(x0 + 1, y0 + 1, seed)
        val ix0 = n00 + (n10 - n00) * sx
        val ix1 = n01 + (n11 - n01) * sx
        return ix0 + (ix1 - ix0) * sy
    }

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val scale = params.getFloat("scale", 0.02f)
        val octaves = params.getInt("octaves", 4).coerceIn(1, 6)
        val persistence = params.getFloat("persistence", 0.5f)

        val pixels = IntArray(width * height)
        var idx = 0
        for (py in 0 until height) {
            for (px in 0 until width) {
                var amp = 1f
                var freq = 1f
                var total = 0f
                var maxAmp = 0f
                for (o in 0 until octaves) {
                    total += smoothNoise(px * scale * freq, py * scale * freq, seed) * amp
                    maxAmp += amp
                    amp *= persistence
                    freq *= 2f
                }
                val n = (total / maxAmp).coerceIn(0f, 1f)
                val v = (n * 255).toInt()
                pixels[idx++] = Color.rgb(v, v, v)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

class WaveInterferenceGenerator : ProceduralGenerator {
    override val id = "wave_interference"
    override val name = "Wave Interference"
    override val description = "Overlapping sinusoidal waves"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("sources", "Wave Sources", ParameterType.INT, "4", 2f, 8f, 1f),
        ParameterDef("frequency", "Frequency", ParameterType.FLOAT, "0.04", 0.01f, 0.12f, 0.005f),
        ParameterDef("amplitude", "Amplitude", ParameterType.FLOAT, "1.0", 0.3f, 2f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val sources = params.getInt("sources", 4).coerceIn(2, 8)
        val freq = params.getFloat("frequency", 0.04f)
        val amp = params.getFloat("amplitude", 1f)

        val centers = Array(sources) {
            floatArrayOf(random.nextFloat() * width, random.nextFloat() * height)
        }

        val pixels = IntArray(width * height)
        var idx = 0
        for (py in 0 until height) {
            for (px in 0 until width) {
                var sum = 0f
                for (c in centers) {
                    val dx = px - c[0]
                    val dy = py - c[1]
                    val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                    sum += sin(dist * freq) * amp
                }
                val n = ((sum / sources) * 0.5f + 0.5f).coerceIn(0f, 1f)
                val v = (n * 255).toInt()
                pixels[idx++] = Color.rgb(v, v, v)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

class StippleGenerator : ProceduralGenerator {
    override val id = "stipple"
    override val name = "Stipple Field"
    override val description = "Point distribution / stippling"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("count", "Point Count", ParameterType.INT, "8000", 500f, 40000f, 500f),
        ParameterDef("size", "Point Size", ParameterType.FLOAT, "1.5", 0.5f, 4f, 0.1f),
        ParameterDef("clustering", "Clustering", ParameterType.FLOAT, "0.0", 0f, 1f, 0.05f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val count = params.getInt("count", 8000).coerceIn(100, 50000)
        val size = params.getFloat("size", 1.5f)
        val clustering = params.getFloat("clustering", 0f)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        for (i in 0 until count) {
            var x = random.nextFloat() * width
            var y = random.nextFloat() * height
            if (clustering > 0.01f && i > 0) {
                // mild attraction toward previous points
                x = x * (1 - clustering) + (random.nextFloat() * width) * clustering
                y = y * (1 - clustering) + (random.nextFloat() * height) * clustering
            }
            canvas.drawCircle(x, y, size, paint)
        }
    }
}
