package com.genesis.proceduralart.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.ui.theme.*

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Spacer(Modifier.height(24.dp))

        Section("Renderer") {
            InfoRow("Mode", "CPU (default)")
            InfoRow("GPU path", "Deferred for stability in v0.01")
        }
        Spacer(Modifier.height(20.dp))
        Section("About") {
            InfoRow("Application", "GENESIS — Procedural Art Studio")
            InfoRow("Version", "v0.01")
            InfoRow("Application ID", "com.genesis.proceduralart")
            InfoRow("Version code", "1")
        }
        Spacer(Modifier.height(20.dp))
        Section("Privacy") {
            Text(
                "GENESIS is offline-first. No accounts, no telemetry, no advertising, no external network calls for core generation and storage.",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftGray
            )
        }
        Spacer(Modifier.height(20.dp))
        Section("v0.01 Scope") {
            Text(
                "Implemented: 48 CPU generators (Clifford/De Jong attractors, Reaction-Diffusion, " +
                    "Cellular Automaton, Circle Packing, Kaleidoscope, Zone Plate, Ink Blot, Voronoi, " +
                    "L-System presets, Particle Field, and more), SVG/PNG/JPEG export, export size presets, colour modes + custom multi-colour, Live preview, Gallery.\n\n" +
                    "Deferred: animation export (GIF/MP4), pure path SVG, advanced blend modes, " +
                    "full L-System text editor, GPU shaders.",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftGray
            )
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Text(title.uppercase(), style = MaterialTheme.typography.labelMedium, color = MidGray)
    Spacer(Modifier.height(8.dp))
    content()
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = SoftGray)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = OffWhite)
    }
}
