package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.ln
import kotlin.math.min
import kotlin.math.sqrt

class MandelbrotGenerator : ProceduralGenerator {
    override val id = "mandelbrot"
    override val name = "Mandelbrot Set"
    override val description = "Classic Mandelbrot fractal (CPU)"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 8
    override val supportsGpu = false // GPU path deferred for v0.01 stability

    override val parameterSchema = listOf(
        ParameterDef("maxIter", "Max Iterations", ParameterType.INT, "80", 20f, 300f, 5f),
        ParameterDef("centerX", "Center X", ParameterType.FLOAT, "-0.5", -2f, 1f, 0.01f),
        ParameterDef("centerY", "Center Y", ParameterType.FLOAT, "0.0", -1.5f, 1.5f, 0.01f),
        ParameterDef("zoom", "Zoom", ParameterType.FLOAT, "1.0", 0.2f, 20f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val maxIter = params.getInt("maxIter", 80).coerceIn(20, 300)
        val cx = params.getFloat("centerX", -0.5f)
        val cy = params.getFloat("centerY", 0f)
        val zoom = params.getFloat("zoom", 1f).coerceAtLeast(0.1f)

        val scale = 3.0 / zoom / min(width, height)
        val offsetX = cx - (width / 2.0) * scale
        val offsetY = cy - (height / 2.0) * scale

        val pixels = IntArray(width * height)
        var idx = 0
        for (py in 0 until height) {
            val y0 = offsetY + py * scale
            for (px in 0 until width) {
                val x0 = offsetX + px * scale
                var x = 0.0
                var y = 0.0
                var iter = 0
                while (x * x + y * y <= 4.0 && iter < maxIter) {
                    val xt = x * x - y * y + x0
                    y = 2 * x * y + y0
                    x = xt
                    iter++
                }
                val c = if (iter >= maxIter) {
                    Color.BLACK
                } else {
                    val t = iter.toFloat() / maxIter
                    val v = (t * 255).toInt().coerceIn(0, 255)
                    Color.rgb(v, v, v)
                }
                pixels[idx++] = c
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

class JuliaGenerator : ProceduralGenerator {
    override val id = "julia"
    override val name = "Julia Set"
    override val description = "Julia set with controllable complex constant"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 8

    override val parameterSchema = listOf(
        ParameterDef("maxIter", "Max Iterations", ParameterType.INT, "80", 20f, 300f, 5f),
        ParameterDef("cReal", "c Real", ParameterType.FLOAT, "-0.7", -1.5f, 1.5f, 0.01f),
        ParameterDef("cImag", "c Imag", ParameterType.FLOAT, "0.27", -1.5f, 1.5f, 0.01f),
        ParameterDef("zoom", "Zoom", ParameterType.FLOAT, "1.0", 0.3f, 10f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val maxIter = params.getInt("maxIter", 80).coerceIn(20, 300)
        val cRe = params.getFloat("cReal", -0.7f).toDouble()
        val cIm = params.getFloat("cImag", 0.27f).toDouble()
        val zoom = params.getFloat("zoom", 1f).coerceAtLeast(0.1f)

        val scale = 3.0 / zoom / min(width, height)
        val offsetX = -(width / 2.0) * scale
        val offsetY = -(height / 2.0) * scale

        val pixels = IntArray(width * height)
        var idx = 0
        for (py in 0 until height) {
            val y0 = offsetY + py * scale
            for (px in 0 until width) {
                var x = offsetX + px * scale
                var y = y0
                var iter = 0
                while (x * x + y * y <= 4.0 && iter < maxIter) {
                    val xt = x * x - y * y + cRe
                    y = 2 * x * y + cIm
                    x = xt
                    iter++
                }
                val c = if (iter >= maxIter) Color.BLACK
                else {
                    val t = iter.toFloat() / maxIter
                    val v = (t * 255).toInt().coerceIn(0, 255)
                    Color.rgb(v, v, v)
                }
                pixels[idx++] = c
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

class SierpinskiGenerator : ProceduralGenerator {
    override val id = "sierpinski"
    override val name = "Sierpiński Triangle"
    override val description = "Classic Sierpiński triangle via chaos game"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("points", "Point Count", ParameterType.INT, "30000", 5000f, 100000f, 1000f),
        ParameterDef("pointSize", "Point Size", ParameterType.FLOAT, "1.0", 0.5f, 3f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val count = params.getInt("points", 30000).coerceIn(1000, 150000)
        val size = params.getFloat("pointSize", 1f)

        val paint = Paint().apply {
            color = Color.WHITE
            strokeWidth = size
            style = Paint.Style.FILL
        }

        val margin = min(width, height) * 0.05f
        val verts = arrayOf(
            floatArrayOf(width / 2f, margin),
            floatArrayOf(margin, height - margin),
            floatArrayOf(width - margin, height - margin)
        )

        var x = width / 2f
        var y = height / 2f

        // Warm-up
        repeat(20) {
            val v = verts[random.nextInt(3)]
            x = (x + v[0]) / 2f
            y = (y + v[1]) / 2f
        }

        for (i in 0 until count) {
            val v = verts[random.nextInt(3)]
            x = (x + v[0]) / 2f
            y = (y + v[1]) / 2f
            canvas.drawPoint(x, y, paint)
        }
    }
}

class RecursiveTreeGenerator : ProceduralGenerator {
    override val id = "recursive_tree"
    override val name = "Recursive Tree"
    override val description = "Branching recursive tree"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("depth", "Depth", ParameterType.INT, "8", 3f, 12f, 1f),
        ParameterDef("angle", "Branch Angle", ParameterType.FLOAT, "25", 10f, 45f, 1f),
        ParameterDef("lengthRatio", "Length Ratio", ParameterType.FLOAT, "0.7", 0.5f, 0.85f, 0.01f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.5", 0.5f, 4f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val depth = params.getInt("depth", 8).coerceIn(2, 12)
        val angleDeg = params.getFloat("angle", 25f)
        val ratio = params.getFloat("lengthRatio", 0.7f)
        val lineWidth = params.getFloat("lineWidth", 1.5f)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lineWidth
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }

        fun branch(x: Float, y: Float, len: Float, angle: Float, d: Int) {
            if (d <= 0 || len < 2f) return
            val rad = Math.toRadians(angle.toDouble())
            val x2 = x + (len * kotlin.math.cos(rad)).toFloat()
            val y2 = y - (len * kotlin.math.sin(rad)).toFloat()
            canvas.drawLine(x, y, x2, y2, paint)
            val spread = angleDeg + (random.nextFloat() - 0.5f) * 8f
            branch(x2, y2, len * ratio, angle + spread, d - 1)
            branch(x2, y2, len * ratio, angle - spread, d - 1)
        }

        val startLen = min(width, height) * 0.28f
        branch(width / 2f, height * 0.92f, startLen, 90f, depth)
    }
}
