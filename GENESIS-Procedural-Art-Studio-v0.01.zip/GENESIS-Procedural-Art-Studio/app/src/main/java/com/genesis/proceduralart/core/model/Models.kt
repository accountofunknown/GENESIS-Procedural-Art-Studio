package com.genesis.proceduralart.core.model

import kotlinx.serialization.Serializable

@Serializable
data class GeneratorId(val value: String)

@Serializable
enum class ParameterType {
    FLOAT, INT, BOOL, COLOR, SEED, CHOICE
}

@Serializable
data class ParameterDef(
    val key: String,
    val label: String,
    val type: ParameterType,
    val defaultValue: String,
    val min: Float? = null,
    val max: Float? = null,
    val step: Float? = null,
    val choices: List<String>? = null,
    val description: String = ""
)

@Serializable
data class ParameterValues(
    val values: Map<String, String> = emptyMap()
) {
    fun getFloat(key: String, default: Float = 0f): Float =
        values[key]?.toFloatOrNull() ?: default

    fun getInt(key: String, default: Int = 0): Int =
        values[key]?.toIntOrNull() ?: default

    fun getBool(key: String, default: Boolean = false): Boolean =
        values[key]?.toBooleanStrictOrNull() ?: default

    fun getLong(key: String, default: Long = 0L): Long =
        values[key]?.toLongOrNull() ?: default

    fun with(key: String, value: String): ParameterValues =
        copy(values = values + (key to value))
}

@Serializable
data class ColorPalette(
    val id: String,
    val name: String,
    val colors: List<Long>, // ARGB packed
    val isCustom: Boolean = false
)

@Serializable
data class LayerState(
    val id: String,
    val name: String,
    val generatorId: String,
    val generatorVersion: Int,
    val seed: Long,
    val parameters: ParameterValues,
    val opacity: Float = 1f,
    val visible: Boolean = true,
    val blendMode: String = "NORMAL"
)

@Serializable
data class Project(
    val id: String,
    val name: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val schemaVersion: Int = 1,
    val width: Int = 1080,
    val height: Int = 1080,
    val backgroundColor: Long = 0xFF000000,
    val layers: List<LayerState> = emptyList(),
    val paletteId: String? = null,
    val isFavorite: Boolean = false,
    val thumbnailPath: String? = null
)

@Serializable
data class ExportConfig(
    val width: Int = 1080,
    val height: Int = 1080,
    val format: String = "PNG", // PNG, JPEG
    val quality: Int = 95,
    val backgroundColor: Long = 0xFF000000,
    val transparent: Boolean = false
)

enum class RendererType {
    AUTO, CPU, GPU
}

data class RenderRequest(
    val project: Project,
    val width: Int,
    val height: Int,
    val renderer: RendererType = RendererType.AUTO,
    val quality: Float = 1f
)

data class RenderResult(
    val success: Boolean,
    val bitmap: android.graphics.Bitmap? = null,
    val error: String? = null,
    val usedRenderer: RendererType = RendererType.CPU,
    val durationMs: Long = 0
)
