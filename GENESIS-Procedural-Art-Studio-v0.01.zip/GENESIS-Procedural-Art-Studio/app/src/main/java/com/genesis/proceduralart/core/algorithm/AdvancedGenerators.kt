package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Classic Lissajous parametric curves */
class LissajousGenerator : ProceduralGenerator {
    override val id = "lissajous"
    override val name = "Lissajous Curves"
    override val description = "Parametric harmonic curves"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("a", "Freq A", ParameterType.INT, "3", 1f, 12f, 1f),
        ParameterDef("b", "Freq B", ParameterType.INT, "4", 1f, 12f, 1f),
        ParameterDef("delta", "Phase", ParameterType.FLOAT, "1.57", 0f, 6.28f, 0.05f),
        ParameterDef("points", "Points", ParameterType.INT, "2000", 200f, 8000f, 100f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.5", 0.5f, 5f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val a = params.getInt("a", 3).coerceIn(1, 12)
        val b = params.getInt("b", 4).coerceIn(1, 12)
        val delta = params.getFloat("delta", 1.57f)
        val points = params.getInt("points", 2000).coerceIn(100, 10000)
        val lw = params.getFloat("lineWidth", 1.5f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lw
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }
        val cx = width / 2f
        val cy = height / 2f
        val rx = width * 0.42f
        val ry = height * 0.42f
        val path = Path()
        for (i in 0..points) {
            val t = i / points.toFloat() * 2f * PI.toFloat()
            val x = cx + rx * sin(a * t + delta)
            val y = cy + ry * sin(b * t)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
}

/** Phyllotaxis (sunflower / golden-angle spiral) */
class PhyllotaxisGenerator : ProceduralGenerator {
    override val id = "phyllotaxis"
    override val name = "Phyllotaxis"
    override val description = "Golden-angle spiral point pattern"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("count", "Points", ParameterType.INT, "600", 50f, 3000f, 50f),
        ParameterDef("scale", "Scale", ParameterType.FLOAT, "8", 2f, 20f, 0.5f),
        ParameterDef("size", "Dot Size", ParameterType.FLOAT, "3", 1f, 10f, 0.5f),
        ParameterDef("angle", "Angle Deg", ParameterType.FLOAT, "137.5", 100f, 170f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val count = params.getInt("count", 600).coerceIn(20, 4000)
        val scale = params.getFloat("scale", 8f)
        val size = params.getFloat("size", 3f)
        val angleDeg = params.getFloat("angle", 137.5f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        val cx = width / 2f
        val cy = height / 2f
        val golden = Math.toRadians(angleDeg.toDouble())
        for (n in 0 until count) {
            val r = scale * sqrt(n.toFloat())
            val theta = n * golden
            val x = cx + (r * cos(theta)).toFloat()
            val y = cy + (r * sin(theta)).toFloat()
            canvas.drawCircle(x, y, size, paint)
        }
    }
}

/** Simple Voronoi via brute-force nearest site */
class VoronoiGenerator : ProceduralGenerator {
    override val id = "voronoi"
    override val name = "Voronoi"
    override val description = "Voronoi diagram from random sites"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 7

    override val parameterSchema = listOf(
        ParameterDef("sites", "Sites", ParameterType.INT, "24", 4f, 80f, 1f),
        ParameterDef("edgeOnly", "Edges Only", ParameterType.FLOAT, "0", 0f, 1f, 1f),
        ParameterDef("jitter", "Jitter", ParameterType.FLOAT, "0.15", 0f, 0.5f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val nSites = params.getInt("sites", 24).coerceIn(3, 100)
        val edgesOnly = params.getFloat("edgeOnly", 0f) >= 0.5f
        val sites = Array(nSites) {
            floatArrayOf(random.nextFloat() * width, random.nextFloat() * height)
        }
        // Downsample for performance on large bitmaps
        val step = if (width * height > 400_000) 2 else 1
        val pixels = IntArray(width * height) { Color.BLACK }
        for (y in 0 until height step step) {
            for (x in 0 until width step step) {
                var best = 0
                var bestD = Float.MAX_VALUE
                var second = Float.MAX_VALUE
                for (i in sites.indices) {
                    val dx = x - sites[i][0]
                    val dy = y - sites[i][1]
                    val d = dx * dx + dy * dy
                    if (d < bestD) {
                        second = bestD
                        bestD = d
                        best = i
                    } else if (d < second) {
                        second = d
                    }
                }
                val c = if (edgesOnly) {
                    val edge = sqrt(second) - sqrt(bestD)
                    if (edge < 1.8f) Color.WHITE else Color.BLACK
                } else {
                    val t = (best * 37 % 200) + 40
                    Color.rgb(t, t, t)
                }
                for (oy in 0 until step) {
                    for (ox in 0 until step) {
                        val xx = x + ox
                        val yy = y + oy
                        if (xx < width && yy < height) pixels[yy * width + xx] = c
                    }
                }
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
        // Draw sites
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        for (s in sites) canvas.drawCircle(s[0], s[1], 2.5f, paint)
    }
}

/** Simple flow-field particle trails */
class FlowFieldGenerator : ProceduralGenerator {
    override val id = "flow_field"
    override val name = "Flow Field"
    override val description = "Particles following a noise-driven flow field"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("particles", "Particles", ParameterType.INT, "400", 50f, 1500f, 50f),
        ParameterDef("steps", "Trail Length", ParameterType.INT, "40", 10f, 120f, 5f),
        ParameterDef("scale", "Field Scale", ParameterType.FLOAT, "0.008", 0.002f, 0.03f, 0.001f),
        ParameterDef("strength", "Strength", ParameterType.FLOAT, "2.5", 0.5f, 6f, 0.1f)
    )

    private fun hashNoise(x: Int, y: Int, seed: Long): Float {
        var n = x * 374761393 + y * 668265263 + seed.toInt()
        n = (n xor (n ushr 13)) * 1274126177
        return ((n xor (n ushr 16)) and 0x7fffffff) / 2147483647f
    }

    private fun fieldAngle(x: Float, y: Float, scale: Float, seed: Long): Float {
        val nx = floor(x * scale).toInt()
        val ny = floor(y * scale).toInt()
        return hashNoise(nx, ny, seed) * 2f * PI.toFloat()
    }

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val particles = params.getInt("particles", 400).coerceIn(20, 2000)
        val steps = params.getInt("steps", 40).coerceIn(5, 150)
        val scale = params.getFloat("scale", 0.008f)
        val strength = params.getFloat("strength", 2.5f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }
        for (p in 0 until particles) {
            var x = random.nextFloat() * width
            var y = random.nextFloat() * height
            val path = Path()
            path.moveTo(x, y)
            for (s in 0 until steps) {
                val ang = fieldAngle(x, y, scale, seed)
                x += cos(ang) * strength
                y += sin(ang) * strength
                if (x < 0 || x >= width || y < 0 || y >= height) break
                path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }
}

/** Topographic-style contour lines from value noise */
class ContourGenerator : ProceduralGenerator {
    override val id = "contours"
    override val name = "Topographic Contours"
    override val description = "Contour lines over a noise height field"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 7

    override val parameterSchema = listOf(
        ParameterDef("scale", "Noise Scale", ParameterType.FLOAT, "0.015", 0.005f, 0.05f, 0.001f),
        ParameterDef("levels", "Contour Levels", ParameterType.INT, "10", 4f, 24f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.2", 0.5f, 3f, 0.1f)
    )

    private fun hash(x: Int, y: Int, seed: Long): Float {
        var n = x * 374761393 + y * 668265263 + seed.toInt()
        n = (n xor (n ushr 13)) * 1274126177
        return ((n xor (n ushr 16)) and 0x7fffffff) / 2147483647f
    }

    private fun smooth(x: Float, y: Float, seed: Long): Float {
        val x0 = floor(x).toInt()
        val y0 = floor(y).toInt()
        val fx = x - x0
        val fy = y - y0
        val sx = fx * fx * (3 - 2 * fx)
        val sy = fy * fy * (3 - 2 * fy)
        val n00 = hash(x0, y0, seed)
        val n10 = hash(x0 + 1, y0, seed)
        val n01 = hash(x0, y0 + 1, seed)
        val n11 = hash(x0 + 1, y0 + 1, seed)
        val ix0 = n00 + (n10 - n00) * sx
        val ix1 = n01 + (n11 - n01) * sx
        return ix0 + (ix1 - ix0) * sy
    }

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val scale = params.getFloat("scale", 0.015f)
        val levels = params.getInt("levels", 10).coerceIn(3, 30)
        val lw = params.getFloat("lineWidth", 1.2f)
        val step = if (width > 600) 2 else 1
        val field = Array(height / step + 1) { y ->
            FloatArray(width / step + 1) { x ->
                smooth(x * step * scale, y * step * scale, seed)
            }
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lw
            color = Color.WHITE
        }
        for (level in 1 until levels) {
            val t = level / levels.toFloat()
            for (gy in 0 until field.size - 1) {
                for (gx in 0 until field[0].size - 1) {
                    val v00 = field[gy][gx]
                    val v10 = field[gy][gx + 1]
                    val v01 = field[gy + 1][gx]
                    // Simple marching: horizontal and vertical crossings
                    if ((v00 - t) * (v10 - t) < 0) {
                        val u = (t - v00) / (v10 - v00 + 1e-6f)
                        val x1 = (gx + u) * step
                        val y1 = gy * step.toFloat()
                        if ((v00 - t) * (v01 - t) < 0) {
                            val u2 = (t - v00) / (v01 - v00 + 1e-6f)
                            canvas.drawLine(x1, y1, gx * step.toFloat(), (gy + u2) * step, paint)
                        }
                    }
                    if ((v00 - t) * (v01 - t) < 0) {
                        val u = (t - v00) / (v01 - v00 + 1e-6f)
                        val x1 = gx * step.toFloat()
                        val y1 = (gy + u) * step
                        if ((v00 - t) * (v10 - t) < 0) {
                            val u2 = (t - v00) / (v10 - v00 + 1e-6f)
                            canvas.drawLine(x1, y1, (gx + u2) * step, gy * step.toFloat(), paint)
                        }
                    }
                }
            }
        }
    }
}

/** Halftone dots from a radial gradient / noise */
class HalftoneGenerator : ProceduralGenerator {
    override val id = "halftone"
    override val name = "Halftone"
    override val description = "Classic halftone dot pattern"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("spacing", "Spacing", ParameterType.FLOAT, "12", 4f, 30f, 1f),
        ParameterDef("maxRadius", "Max Radius", ParameterType.FLOAT, "5", 1f, 14f, 0.5f),
        ParameterDef("centerBias", "Center Bias", ParameterType.FLOAT, "0.6", 0f, 1f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val spacing = params.getFloat("spacing", 12f).coerceAtLeast(3f)
        val maxR = params.getFloat("maxRadius", 5f)
        val bias = params.getFloat("centerBias", 0.6f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        val cx = width / 2f
        val cy = height / 2f
        val maxDist = hypot(cx, cy)
        var y = spacing / 2f
        while (y < height) {
            var x = spacing / 2f
            while (x < width) {
                val d = hypot(x - cx, y - cy) / maxDist
                val intensity = (1f - d * bias).coerceIn(0f, 1f)
                val r = maxR * intensity * (0.7f + 0.3f * random.nextFloat())
                if (r > 0.3f) canvas.drawCircle(x, y, r, paint)
                x += spacing
            }
            y += spacing
        }
    }
}

/** Simple L-system plant / bush */
class LSystemGenerator : ProceduralGenerator {
    override val id = "lsystem"
    override val name = "L-System Plant"
    override val description = "Turtle-graphics L-system with rule presets"
    override val category = "Fractal"
    override val version = 2
    override val estimatedCost = 4

    // preset: 0=Plant, 1=Bush, 2=Triangle, 3=Koch-ish
    override val parameterSchema = listOf(
        ParameterDef("preset", "Rule Preset", ParameterType.INT, "0", 0f, 3f, 1f),
        ParameterDef("iterations", "Iterations", ParameterType.INT, "4", 1f, 6f, 1f),
        ParameterDef("angle", "Angle", ParameterType.FLOAT, "25", 10f, 45f, 1f),
        ParameterDef("length", "Segment Length", ParameterType.FLOAT, "8", 3f, 20f, 0.5f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.5", 0.5f, 4f, 0.1f)
    )

    private data class Rules(val axiom: String, val map: Map<Char, String>)

    private fun rulesFor(preset: Int): Rules = when (preset) {
        1 -> Rules( // Bush
            "F",
            mapOf('F' to "FF+[+F-F-F]-[-F+F+F]")
        )
        2 -> Rules( // Sierpinski-like triangle
            "F-G-G",
            mapOf('F' to "F-G+F+G-F", 'G' to "GG")
        )
        3 -> Rules( // Koch curve style
            "F",
            mapOf('F' to "F+F-F-F+F")
        )
        else -> Rules( // Classic plant
            "X",
            mapOf('X' to "F+[[X]-X]-F[-FX]+X", 'F' to "FF")
        )
    }

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val preset = params.getInt("preset", 0).coerceIn(0, 3)
        val iters = params.getInt("iterations", 4).coerceIn(1, 6)
        val angle = params.getFloat("angle", 25f)
        val len = params.getFloat("length", 8f)
        val lw = params.getFloat("lineWidth", 1.5f)
        val rules = rulesFor(preset)

        var s = rules.axiom
        repeat(iters) {
            val sb = StringBuilder()
            for (c in s) {
                sb.append(rules.map[c] ?: c.toString())
            }
            s = sb.toString()
            if (s.length > 50_000) return@repeat
        }

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lw
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }

        data class State(var x: Float, var y: Float, var a: Float)
        val stack = ArrayDeque<State>()
        var x = width / 2f
        var y = height * 0.92f
        var a = -90f
        val radFactor = (Math.PI / 180.0).toFloat()

        // For triangle/koch start higher / adjust
        if (preset == 2 || preset == 3) {
            y = height * 0.75f
            a = if (preset == 3) 0f else -90f
        }

        for (c in s) {
            when (c) {
                'F', 'G' -> {
                    val nx = x + kotlin.math.cos(a * radFactor) * len
                    val ny = y + kotlin.math.sin(a * radFactor) * len
                    canvas.drawLine(x, y, nx, ny, paint)
                    x = nx; y = ny
                }
                '+' -> a += angle
                '-' -> a -= angle
                '[' -> stack.addLast(State(x, y, a))
                ']' -> {
                    val st = stack.removeLastOrNull() ?: continue
                    x = st.x; y = st.y; a = st.a
                }
            }
        }
    }
}


/** Truchet tile pattern */
class TruchetGenerator : ProceduralGenerator {
    override val id = "truchet"
    override val name = "Truchet Tiles"
    override val description = "Random quarter-circle tile pattern"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("tiles", "Tiles Across", ParameterType.INT, "12", 4f, 32f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "2", 0.5f, 6f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("tiles", 12).coerceIn(3, 40)
        val lw = params.getFloat("lineWidth", 2f)
        val tile = min(width, height) / n.toFloat()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lw
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }
        val cols = (width / tile).toInt() + 1
        val rows = (height / tile).toInt() + 1
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val x = c * tile
                val y = r * tile
                if (random.nextBoolean()) {
                    // arc from left to top, and right to bottom
                    canvas.drawArc(x - tile, y - tile, x + tile, y + tile, 0f, 90f, false, paint)
                    canvas.drawArc(x, y, x + 2 * tile, y + 2 * tile, 180f, 90f, false, paint)
                } else {
                    canvas.drawArc(x, y - tile, x + 2 * tile, y + tile, 90f, 90f, false, paint)
                    canvas.drawArc(x - tile, y, x + tile, y + 2 * tile, 270f, 90f, false, paint)
                }
            }
        }
    }
}

/** Spiral galaxy-ish arms */
class SpiralGalaxyGenerator : ProceduralGenerator {
    override val id = "spiral_galaxy"
    override val name = "Spiral Galaxy"
    override val description = "Logarithmic spiral arms with star points"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("arms", "Arms", ParameterType.INT, "3", 2f, 8f, 1f),
        ParameterDef("stars", "Stars per Arm", ParameterType.INT, "400", 50f, 1500f, 50f),
        ParameterDef("twist", "Twist", ParameterType.FLOAT, "0.25", 0.05f, 0.6f, 0.01f),
        ParameterDef("spread", "Spread", ParameterType.FLOAT, "0.15", 0.02f, 0.4f, 0.01f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val arms = params.getInt("arms", 3).coerceIn(2, 8)
        val stars = params.getInt("stars", 400).coerceIn(20, 2000)
        val twist = params.getFloat("twist", 0.25f)
        val spread = params.getFloat("spread", 0.15f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) * 0.45f
        for (arm in 0 until arms) {
            val base = arm * (2 * PI / arms)
            for (i in 0 until stars) {
                val t = i / stars.toFloat()
                val r = t * maxR
                val theta = base + t * twist * 2 * PI + (random.nextFloat() - 0.5f) * spread
                val x = cx + (r * cos(theta)).toFloat()
                val y = cy + (r * sin(theta)).toFloat()
                val size = 0.8f + (1f - t) * 2.2f * random.nextFloat()
                canvas.drawCircle(x, y, size, paint)
            }
        }
        // core
        canvas.drawCircle(cx, cy, 4f, paint)
    }
}

/** Plasma / multi-sine interference field */
class PlasmaGenerator : ProceduralGenerator {
    override val id = "plasma"
    override val name = "Plasma"
    override val description = "Classic multi-sine plasma field"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("freq", "Frequency", ParameterType.FLOAT, "0.04", 0.01f, 0.12f, 0.005f),
        ParameterDef("time", "Phase", ParameterType.FLOAT, "0", 0f, 6.28f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val freq = params.getFloat("freq", 0.04f)
        // Use full seed for visible phase motion in Live mode
        val time = params.getFloat("time", 0f) + (seed and 0xFFFFFFL) * 0.00002f
        val pixels = IntArray(width * height)
        var idx = 0
        for (y in 0 until height) {
            for (x in 0 until width) {
                val v1 = sin(x * freq + time)
                val v2 = sin(y * freq + time * 0.7f)
                val v3 = sin((x + y) * freq * 0.5f + time)
                val v4 = sin(sqrt((x - width / 2f).pow(2) + (y - height / 2f).pow(2)) * freq + time)
                val v = ((v1 + v2 + v3 + v4) * 0.25f + 1f) * 0.5f
                val c = (v.coerceIn(0f, 1f) * 255).toInt()
                pixels[idx++] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}


/** Particle field driven by simple noise forces */
class ParticleFieldGenerator : ProceduralGenerator {
    override val id = "particle_field"
    override val name = "Particle Field"
    override val description = "Particles advected by a seeded force field"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("count", "Particles", ParameterType.INT, "800", 100f, 3000f, 50f),
        ParameterDef("steps", "Trail Steps", ParameterType.INT, "40", 5f, 120f, 5f),
        ParameterDef("force", "Force Scale", ParameterType.FLOAT, "1.2", 0.2f, 3f, 0.1f),
        ParameterDef("pointSize", "Point Size", ParameterType.FLOAT, "1.5", 0.5f, 4f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val count = params.getInt("count", 800).coerceIn(50, 4000)
        val steps = params.getInt("steps", 40).coerceIn(3, 150)
        val force = params.getFloat("force", 1.2f)
        val size = params.getFloat("pointSize", 1.5f)

        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.WHITE
        }

        // Simple hash noise for force direction
        fun noise2(ix: Int, iy: Int): Float {
            var n = ix * 374761393 + iy * 668265263 + seed.toInt()
            n = (n xor (n ushr 13)) * 1274126177
            return ((n xor (n ushr 16)) and 0xFFFF) / 65535f
        }

        for (i in 0 until count) {
            var x = random.nextFloat() * width
            var y = random.nextFloat() * height
            for (s in 0 until steps) {
                val gx = ((x / width) * 12f).toInt()
                val gy = ((y / height) * 12f).toInt()
                val a = noise2(gx, gy) * Math.PI.toFloat() * 2f
                x += kotlin.math.cos(a) * force * 2.5f
                y += kotlin.math.sin(a) * force * 2.5f
                if (x < 0 || x >= width || y < 0 || y >= height) break
                val alpha = ((1f - s.toFloat() / steps) * 200).toInt().coerceIn(20, 220)
                paint.color = Color.argb(alpha, 255, 255, 255)
                canvas.drawCircle(x, y, size, paint)
            }
        }
    }
}

