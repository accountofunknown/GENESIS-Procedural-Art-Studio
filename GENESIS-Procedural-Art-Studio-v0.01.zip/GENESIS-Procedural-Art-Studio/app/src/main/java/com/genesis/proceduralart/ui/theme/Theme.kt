package com.genesis.proceduralart.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GenesisDarkColorScheme = darkColorScheme(
    primary = PureWhite,
    onPrimary = PureBlack,
    primaryContainer = DarkGray,
    onPrimaryContainer = OffWhite,
    secondary = SoftGray,
    onSecondary = PureBlack,
    secondaryContainer = Graphite,
    onSecondaryContainer = OffWhite,
    tertiary = LightGray,
    onTertiary = PureBlack,
    background = PureBlack,
    onBackground = PureWhite,
    surface = NearBlack,
    onSurface = OffWhite,
    surfaceVariant = Charcoal,
    onSurfaceVariant = SoftGray,
    outline = MidGray,
    outlineVariant = DarkGray,
    error = Color(0xFFCF6679),
    onError = PureBlack
)

@Composable
fun GenesisTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GenesisDarkColorScheme,
        typography = GenesisTypography,
        content = content
    )
}
