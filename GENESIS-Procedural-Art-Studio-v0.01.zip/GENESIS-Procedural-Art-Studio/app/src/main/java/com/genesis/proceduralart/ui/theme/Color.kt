package com.genesis.proceduralart.ui.theme

import androidx.compose.ui.graphics.Color

// AMOLED-friendly monochrome palette
val PureBlack = Color(0xFF000000)
val NearBlack = Color(0xFF0A0A0A)
val Charcoal = Color(0xFF141414)
val Graphite = Color(0xFF1E1E1E)
val DarkGray = Color(0xFF2A2A2A)
val MidGray = Color(0xFF4A4A4A)
val SoftGray = Color(0xFF8A8A8A)
val LightGray = Color(0xFFB0B0B0)
val OffWhite = Color(0xFFE8E8E8)
val PureWhite = Color(0xFFFFFFFF)
