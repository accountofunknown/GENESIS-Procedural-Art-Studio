package com.genesis.proceduralart.core.random

import kotlin.random.Random

/**
 * Deterministic random source. Same seed always produces the same sequence.
 * Do not use kotlin.random.Random.Default for generators.
 */
class SeededRandom(private val seed: Long) {
    private val random = Random(seed)

    fun nextDouble(): Double = random.nextDouble()
    fun nextDouble(until: Double): Double = random.nextDouble(until)
    fun nextDouble(from: Double, until: Double): Double = random.nextDouble(from, until)
    fun nextFloat(): Float = random.nextFloat()
    fun nextInt(): Int = random.nextInt()
    fun nextInt(until: Int): Int = random.nextInt(until)
    fun nextInt(from: Int, until: Int): Int = random.nextInt(from, until)
    fun nextLong(): Long = random.nextLong()
    fun nextBoolean(): Boolean = random.nextBoolean()
    fun nextBytes(size: Int): ByteArray = random.nextBytes(size)

    companion object {
        fun create(seed: Long = System.currentTimeMillis()): SeededRandom = SeededRandom(seed)
        fun randomSeed(): Long = Random.Default.nextLong()
    }
}
