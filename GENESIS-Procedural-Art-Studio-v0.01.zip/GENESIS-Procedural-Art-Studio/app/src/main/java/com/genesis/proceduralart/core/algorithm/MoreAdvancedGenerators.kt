package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Lorenz strange attractor (3D projected) */
class LorenzAttractorGenerator : ProceduralGenerator {
    override val id = "lorenz"
    override val name = "Lorenz Attractor"
    override val description = "Classic chaotic Lorenz butterfly"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("points", "Points", ParameterType.INT, "50000", 10000f, 150000f, 5000f),
        ParameterDef("sigma", "Sigma", ParameterType.FLOAT, "10", 5f, 20f, 0.5f),
        ParameterDef("rho", "Rho", ParameterType.FLOAT, "28", 15f, 40f, 0.5f),
        ParameterDef("beta", "Beta", ParameterType.FLOAT, "2.67", 1f, 5f, 0.1f),
        ParameterDef("dt", "Step", ParameterType.FLOAT, "0.005", 0.002f, 0.02f, 0.001f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("points", 50000).coerceIn(5000, 200000)
        val sigma = params.getFloat("sigma", 10f)
        val rho = params.getFloat("rho", 28f)
        val beta = params.getFloat("beta", 8f / 3f)
        val dt = params.getFloat("dt", 0.005f)
        canvas.drawColor(Color.BLACK)
        var x = 0.1f + (seed % 1000) * 0.00001f
        var y = 0f
        var z = 0f
        val xs = FloatArray(n); val ys = FloatArray(n)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (i in 0 until n) {
            val dx = sigma * (y - x)
            val dy = x * (rho - z) - y
            val dz = x * y - beta * z
            x += dx * dt; y += dy * dt; z += dz * dt
            xs[i] = x; ys[i] = z // project XZ
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (z < minY) minY = z; if (z > maxY) maxY = z
        }
        val pad = 0.08f
        val sx = width * (1 - 2 * pad) / (maxX - minX).coerceAtLeast(1e-4f)
        val sy = height * (1 - 2 * pad) / (maxY - minY).coerceAtLeast(1e-4f)
        val ox = width * pad - minX * sx
        val oy = height * pad - minY * sy
        val paint = Paint().apply { color = Color.argb(45, 255, 255, 255) }
        for (i in 0 until n) canvas.drawPoint(xs[i] * sx + ox, ys[i] * sy + oy, paint)
    }
}

/** Rössler attractor */
class RosslerAttractorGenerator : ProceduralGenerator {
    override val id = "rossler"
    override val name = "Rössler Attractor"
    override val description = "Rössler chaotic band attractor"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("points", "Points", ParameterType.INT, "60000", 10000f, 150000f, 5000f),
        ParameterDef("a", "a", ParameterType.FLOAT, "0.2", 0.1f, 0.4f, 0.01f),
        ParameterDef("b", "b", ParameterType.FLOAT, "0.2", 0.1f, 0.4f, 0.01f),
        ParameterDef("c", "c", ParameterType.FLOAT, "5.7", 4f, 14f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("points", 60000).coerceIn(5000, 200000)
        val a = params.getFloat("a", 0.2f)
        val b = params.getFloat("b", 0.2f)
        val c = params.getFloat("c", 5.7f)
        val dt = 0.02f
        canvas.drawColor(Color.BLACK)
        var x = 0.1f; var y = 0f; var z = 0f
        val xs = FloatArray(n); val ys = FloatArray(n)
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for (i in 0 until n) {
            val dx = -y - z
            val dy = x + a * y
            val dz = b + z * (x - c)
            x += dx * dt; y += dy * dt; z += dz * dt
            xs[i] = x; ys[i] = y
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val pad = 0.08f
        val sx = width * (1 - 2 * pad) / (maxX - minX).coerceAtLeast(1e-4f)
        val sy = height * (1 - 2 * pad) / (maxY - minY).coerceAtLeast(1e-4f)
        val ox = width * pad - minX * sx
        val oy = height * pad - minY * sy
        val paint = Paint().apply { color = Color.argb(50, 255, 255, 255) }
        for (i in 0 until n) canvas.drawPoint(xs[i] * sx + ox, ys[i] * sy + oy, paint)
    }
}

/** Superformula (Gielis) shapes */
class SuperformulaGenerator : ProceduralGenerator {
    override val id = "superformula"
    override val name = "Superformula"
    override val description = "Gielis superformula organic shapes"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("m", "Symmetry m", ParameterType.FLOAT, "6", 1f, 16f, 0.5f),
        ParameterDef("n1", "n1", ParameterType.FLOAT, "1", 0.2f, 10f, 0.1f),
        ParameterDef("n2", "n2", ParameterType.FLOAT, "1", 0.2f, 10f, 0.1f),
        ParameterDef("n3", "n3", ParameterType.FLOAT, "1", 0.2f, 10f, 0.1f),
        ParameterDef("layers", "Layers", ParameterType.INT, "4", 1f, 12f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val m = params.getFloat("m", 6f)
        val n1 = params.getFloat("n1", 1f).coerceAtLeast(0.05f)
        val n2 = params.getFloat("n2", 1f)
        val n3 = params.getFloat("n3", 1f)
        val layers = params.getInt("layers", 4).coerceIn(1, 16)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.4f; color = Color.WHITE
        }
        val cx = width / 2f; val cy = height / 2f
        val maxR = min(width, height) * 0.42f
        val phase = ((seed and 0xFFFF).toFloat() / 65535f) * 2f * PI.toFloat()
        for (layer in 1..layers) {
            val scale = layer / layers.toFloat()
            val path = Path()
            val steps = 720
            for (i in 0..steps) {
                val theta = i / steps.toFloat() * 2f * PI.toFloat() + phase
                val t1 = abs(cos(m * theta / 4f)).pow(n2)
                val t2 = abs(sin(m * theta / 4f)).pow(n3)
                val r = (t1 + t2).pow(-1f / n1).coerceIn(0.01f, 10f)
                val x = cx + cos(theta) * r * maxR * scale
                val y = cy + sin(theta) * r * maxR * scale
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, paint)
        }
    }
}

/** Lyapunov fractal (logistic family) */
class LyapunovFractalGenerator : ProceduralGenerator {
    override val id = "lyapunov"
    override val name = "Lyapunov Fractal"
    override val description = "Lyapunov exponent map over parameter space"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 9

    override val parameterSchema = listOf(
        ParameterDef("iters", "Iterations", ParameterType.INT, "80", 30f, 150f, 5f),
        ParameterDef("seq", "Sequence AB", ParameterType.FLOAT, "0.5", 0f, 1f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val iters = params.getInt("iters", 80).coerceIn(20, 200)
        val seqBias = params.getFloat("seq", 0.5f)
        val pixels = IntArray(width * height)
        val a0 = 2.0 + (seed % 100) * 0.01
        for (py in 0 until height) {
            for (px in 0 until width) {
                val a = 3.4 + px / width.toDouble() * 0.6
                val b = 3.4 + py / height.toDouble() * 0.6
                var x = 0.5
                var sum = 0.0
                var valid = true
                for (i in 0 until iters) {
                    val r = if ((i % 2 == 0) == seqBias > 0.5) a else b
                    x = r * x * (1 - x)
                    val deriv = abs(r * (1 - 2 * x))
                    if (deriv < 1e-12) { valid = false; break }
                    sum += ln(deriv)
                }
                val lam = if (valid) (sum / iters).toFloat() else -2f
                // Map Lyapunov to grayscale
                val t = ((lam + 2f) / 3f).coerceIn(0f, 1f)
                val c = (t * 255).toInt()
                pixels[py * width + px] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Diffusion-limited aggregation */
class DlaGenerator : ProceduralGenerator {
    override val id = "dla"
    override val name = "DLA Cluster"
    override val description = "Diffusion-limited aggregation growth"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 8

    override val parameterSchema = listOf(
        ParameterDef("particles", "Particles", ParameterType.INT, "2500", 500f, 8000f, 100f),
        ParameterDef("stickiness", "Stickiness", ParameterType.FLOAT, "1", 0.2f, 1f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("particles", 2500).coerceIn(200, 10000)
        val stick = params.getFloat("stickiness", 1f)
        canvas.drawColor(Color.BLACK)
        val gridW = min(width, 360)
        val gridH = min(height, 360)
        val scaleX = width / gridW.toFloat()
        val scaleY = height / gridH.toFloat()
        val stuck = BooleanArray(gridW * gridH)
        fun idx(x: Int, y: Int) = y * gridW + x
        // seed crystal at center
        stuck[idx(gridW / 2, gridH / 2)] = true
        val paint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        canvas.drawCircle(width / 2f, height / 2f, 2f, paint)

        fun hasNeighbor(x: Int, y: Int): Boolean {
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val nx = x + dx; val ny = y + dy
                if (nx in 0 until gridW && ny in 0 until gridH && stuck[idx(nx, ny)]) return true
            }
            return false
        }

        var radius = 8
        for (p in 0 until n) {
            // spawn on circle
            val ang = random.nextFloat() * 2f * PI.toFloat()
            var x = (gridW / 2 + cos(ang) * radius).toInt().coerceIn(1, gridW - 2)
            var y = (gridH / 2 + sin(ang) * radius).toInt().coerceIn(1, gridH - 2)
            var steps = 0
            while (steps < 4000) {
                steps++
                x = (x + random.nextInt(3) - 1).coerceIn(1, gridW - 2)
                y = (y + random.nextInt(3) - 1).coerceIn(1, gridH - 2)
                val dist = hypot((x - gridW / 2).toFloat(), (y - gridH / 2).toFloat())
                if (dist > radius + 20) break
                if (hasNeighbor(x, y) && random.nextFloat() <= stick) {
                    stuck[idx(x, y)] = true
                    if (dist + 2 > radius) radius = (dist + 2).toInt()
                    canvas.drawCircle(x * scaleX, y * scaleY, 1.2f * max(scaleX, scaleY), paint)
                    break
                }
            }
        }
    }
}

/** Epicycloid / Fourier drawing */
class EpicycloidGenerator : ProceduralGenerator {
    override val id = "epicycloid"
    override val name = "Epicycloid"
    override val description = "Rolling-circle epicycloid curves"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("R", "Fixed R", ParameterType.FLOAT, "5", 2f, 12f, 0.5f),
        ParameterDef("r", "Rolling r", ParameterType.FLOAT, "3", 1f, 10f, 0.25f),
        ParameterDef("d", "Pen distance", ParameterType.FLOAT, "3", 0.5f, 10f, 0.25f),
        ParameterDef("turns", "Turns", ParameterType.FLOAT, "12", 2f, 40f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val R = params.getFloat("R", 5f)
        val r = params.getFloat("r", 3f).coerceAtLeast(0.2f)
        val d = params.getFloat("d", 3f)
        val turns = params.getFloat("turns", 12f)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.3f; color = Color.WHITE
        }
        val cx = width / 2f; val cy = height / 2f
        val scale = min(width, height) * 0.15f / max(R, r)
        val path = Path()
        val steps = (turns * 400).toInt().coerceIn(400, 12000)
        val phase = ((seed and 0xFFFF).toFloat() / 65535f) * 2f * PI.toFloat()
        for (i in 0..steps) {
            val t = i / steps.toFloat() * turns * 2f * PI.toFloat() + phase
            val x = (R + r) * cos(t) - d * cos((R + r) / r * t)
            val y = (R + r) * sin(t) - d * sin((R + r) / r * t)
            val px = cx + x * scale
            val py = cy + y * scale
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        canvas.drawPath(path, paint)
    }
}

/** Quasicrystal interference */
class QuasicrystalGenerator : ProceduralGenerator {
    override val id = "quasicrystal"
    override val name = "Quasicrystal"
    override val description = "Multi-wave quasicrystal interference"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 7

    override val parameterSchema = listOf(
        ParameterDef("waves", "Waves", ParameterType.INT, "5", 3f, 11f, 1f),
        ParameterDef("scale", "Scale", ParameterType.FLOAT, "12", 4f, 30f, 1f),
        ParameterDef("contrast", "Contrast", ParameterType.FLOAT, "1.2", 0.5f, 2.5f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val waves = params.getInt("waves", 5).coerceIn(3, 13)
        val scale = params.getFloat("scale", 12f)
        val contrast = params.getFloat("contrast", 1.2f)
        val phase = ((seed and 0xFFFF).toFloat() / 65535f) * 2f * PI.toFloat()
        val pixels = IntArray(width * height)
        val angles = FloatArray(waves) { i -> i * PI.toFloat() / waves }
        for (y in 0 until height) {
            for (x in 0 until width) {
                val nx = (x - width / 2f) / width * scale
                val ny = (y - height / 2f) / height * scale
                var s = 0f
                for (i in 0 until waves) {
                    val a = angles[i]
                    s += cos(nx * cos(a) + ny * sin(a) + phase * (1 + i * 0.1f))
                }
                s = ((s / waves) * contrast + 1f) * 0.5f
                val c = (s.coerceIn(0f, 1f) * 255).toInt()
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Double pendulum path */
class DoublePendulumGenerator : ProceduralGenerator {
    override val id = "double_pendulum"
    override val name = "Double Pendulum"
    override val description = "Chaotic double-pendulum trail"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("steps", "Steps", ParameterType.INT, "8000", 2000f, 20000f, 500f),
        ParameterDef("g", "Gravity", ParameterType.FLOAT, "9.8", 5f, 20f, 0.5f),
        ParameterDef("l1", "Length 1", ParameterType.FLOAT, "1", 0.5f, 2f, 0.05f),
        ParameterDef("l2", "Length 2", ParameterType.FLOAT, "1", 0.5f, 2f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val steps = params.getInt("steps", 8000).coerceIn(500, 30000)
        val g = params.getFloat("g", 9.8f)
        val l1 = params.getFloat("l1", 1f)
        val l2 = params.getFloat("l2", 1f)
        val m1 = 1f; val m2 = 1f
        val dt = 0.01f
        var a1 = PI.toFloat() / 2f + (seed % 1000) * 0.0001f
        var a2 = PI.toFloat() / 2f + (seed % 700) * 0.0002f
        var w1 = 0f; var w2 = 0f
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.2f; color = Color.WHITE; strokeCap = Paint.Cap.ROUND
        }
        val cx = width / 2f; val cy = height * 0.35f
        val scale = min(width, height) * 0.2f
        val path = Path()
        for (i in 0 until steps) {
            val den = 2 * m1 + m2 - m2 * cos(2 * a1 - 2 * a2)
            val a1a = (-g * (2 * m1 + m2) * sin(a1) - m2 * g * sin(a1 - 2 * a2) -
                    2 * sin(a1 - a2) * m2 * (w2 * w2 * l2 + w1 * w1 * l1 * cos(a1 - a2))) / (l1 * den)
            val a2a = (2 * sin(a1 - a2) * (w1 * w1 * l1 * (m1 + m2) + g * (m1 + m2) * cos(a1) +
                    w2 * w2 * l2 * m2 * cos(a1 - a2))) / (l2 * den)
            w1 += a1a * dt; w2 += a2a * dt
            a1 += w1 * dt; a2 += w2 * dt
            val x = cx + scale * (l1 * sin(a1) + l2 * sin(a2))
            val y = cy + scale * (l1 * cos(a1) + l2 * cos(a2))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
}

/** Apollonian-ish circle packing recursion */
class ApollonianGenerator : ProceduralGenerator {
    override val id = "apollonian"
    override val name = "Apollonian Gasket"
    override val description = "Recursive circle packing gasket"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("depth", "Depth", ParameterType.INT, "6", 3f, 8f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.2", 0.5f, 3f, 0.1f)
    )

    data class C(val x: Float, val y: Float, val r: Float)

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val depth = params.getInt("depth", 6).coerceIn(2, 9)
        val lw = params.getFloat("lineWidth", 1.2f)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lw; color = Color.WHITE
        }
        val cx = width / 2f; val cy = height / 2f
        val R = min(width, height) * 0.48f
        fun drawC(c: C) = canvas.drawCircle(c.x, c.y, c.r, paint)
        val outer = C(cx, cy, R)
        drawC(outer)
        // three mutually tangent inside
        val r0 = R / 2.2f
        val c1 = C(cx, cy - r0 * 0.6f, r0)
        val c2 = C(cx - r0 * 0.7f, cy + r0 * 0.5f, r0 * 0.9f)
        val c3 = C(cx + r0 * 0.7f, cy + r0 * 0.5f, r0 * 0.85f)
        val queue = ArrayDeque<Triple<C, C, C>>()
        listOf(c1, c2, c3).forEach { drawC(it) }
        queue.add(Triple(c1, c2, c3))
        queue.add(Triple(outer, c1, c2))
        queue.add(Triple(outer, c2, c3))
        queue.add(Triple(outer, c3, c1))
        var d = 0
        while (queue.isNotEmpty() && d < 4000) {
            val (a, b, c) = queue.removeFirst()
            val k1 = 1f / a.r; val k2 = 1f / b.r; val k3 = 1f / c.r
            // Descartes theorem
            val k4 = k1 + k2 + k3 + 2f * sqrt(max(0f, k1 * k2 + k2 * k3 + k3 * k1))
            val r4 = 1f / k4
            if (r4 < 1.5f) continue
            // approximate center as weighted average
            val s = k1 + k2 + k3
            val x4 = (a.x * k1 + b.x * k2 + c.x * k3) / s
            val y4 = (a.y * k1 + b.y * k2 + c.y * k3) / s
            // nudge toward gap
            val mx = (a.x + b.x + c.x) / 3f
            val my = (a.y + b.y + c.y) / 3f
            val nx = x4 * 0.3f + mx * 0.7f
            val ny = y4 * 0.3f + my * 0.7f
            val c4 = C(nx, ny, r4)
            drawC(c4)
            d++
            if (d < depth * 80) {
                queue.add(Triple(a, b, c4))
                queue.add(Triple(b, c, c4))
                queue.add(Triple(c, a, c4))
            }
        }
    }
}

/** Mandala iris / radial interference */
class IrisFieldGenerator : ProceduralGenerator {
    override val id = "iris_field"
    override val name = "Iris Field"
    override val description = "Radial iris interference field"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("rings", "Rings", ParameterType.FLOAT, "18", 4f, 40f, 1f),
        ParameterDef("petals", "Petals", ParameterType.FLOAT, "8", 2f, 24f, 1f),
        ParameterDef("contrast", "Contrast", ParameterType.FLOAT, "1.3", 0.5f, 2.5f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val rings = params.getFloat("rings", 18f)
        val petals = params.getFloat("petals", 8f)
        val contrast = params.getFloat("contrast", 1.3f)
        val phase = ((seed and 0xFFFF).toFloat() / 65535f) * 2f * PI.toFloat()
        val pixels = IntArray(width * height)
        val cx = width / 2f; val cy = height / 2f
        val maxR = min(width, height) * 0.5f
        for (y in 0 until height) {
            for (x in 0 until width) {
                val dx = x - cx; val dy = y - cy
                val r = hypot(dx, dy) / maxR
                val a = atan2(dy, dx)
                val v = sin(r * rings * PI.toFloat() + phase) *
                        cos(a * petals + phase * 0.5f) *
                        exp(-r * 1.2f)
                val t = ((v * contrast + 1f) * 0.5f).coerceIn(0f, 1f)
                val c = (t * 255).toInt()
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}
