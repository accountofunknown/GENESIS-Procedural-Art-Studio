package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Clifford attractor — dense point cloud from iterative map */
class CliffordAttractorGenerator : ProceduralGenerator {
    override val id = "clifford"
    override val name = "Clifford Attractor"
    override val description = "Classic Clifford strange attractor point cloud"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("points", "Points", ParameterType.INT, "80000", 10000f, 200000f, 5000f),
        ParameterDef("a", "A", ParameterType.FLOAT, "-1.4", -2f, 2f, 0.05f),
        ParameterDef("b", "B", ParameterType.FLOAT, "1.6", -2f, 2f, 0.05f),
        ParameterDef("c", "C", ParameterType.FLOAT, "1.0", -2f, 2f, 0.05f),
        ParameterDef("d", "D", ParameterType.FLOAT, "0.7", -2f, 2f, 0.05f),
        ParameterDef("pointSize", "Point Size", ParameterType.FLOAT, "1.0", 0.5f, 3f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("points", 80000).coerceIn(5000, 250000)
        val a = params.getFloat("a", -1.4f)
        val b = params.getFloat("b", 1.6f)
        val c = params.getFloat("c", 1.0f)
        val d = params.getFloat("d", 0.7f)
        val size = params.getFloat("pointSize", 1f)

        canvas.drawColor(Color.BLACK)
        // Warm-up + bounds
        var x = random.nextFloat() * 0.1f
        var y = random.nextFloat() * 0.1f
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        repeat(200) {
            val nx = sin(a * y) + c * cos(a * x)
            val ny = sin(b * x) + d * cos(b * y)
            x = nx; y = ny
        }
        for (i in 0 until n) {
            val nx = sin(a * y) + c * cos(a * x)
            val ny = sin(b * x) + d * cos(b * y)
            x = nx; y = ny
            xs[i] = x; ys[i] = y
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
        val pad = 0.08f
        val spanX = (maxX - minX).coerceAtLeast(1e-4f)
        val spanY = (maxY - minY).coerceAtLeast(1e-4f)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(40, 255, 255, 255)
        }
        val sx = width * (1f - 2 * pad) / spanX
        val sy = height * (1f - 2 * pad) / spanY
        val ox = width * pad - minX * sx
        val oy = height * pad - minY * sy
        for (i in 0 until n) {
            canvas.drawCircle(xs[i] * sx + ox, ys[i] * sy + oy, size, paint)
        }
    }
}

/** Peter de Jong attractor */
class DeJongAttractorGenerator : ProceduralGenerator {
    override val id = "dejong"
    override val name = "De Jong Attractor"
    override val description = "Peter de Jong iterative attractor"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("points", "Points", ParameterType.INT, "90000", 10000f, 200000f, 5000f),
        ParameterDef("a", "A", ParameterType.FLOAT, "1.4", -3f, 3f, 0.05f),
        ParameterDef("b", "B", ParameterType.FLOAT, "-2.3", -3f, 3f, 0.05f),
        ParameterDef("c", "C", ParameterType.FLOAT, "2.4", -3f, 3f, 0.05f),
        ParameterDef("d", "D", ParameterType.FLOAT, "-2.1", -3f, 3f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("points", 90000).coerceIn(5000, 250000)
        val a = params.getFloat("a", 1.4f)
        val b = params.getFloat("b", -2.3f)
        val c = params.getFloat("c", 2.4f)
        val d = params.getFloat("d", -2.1f)
        canvas.drawColor(Color.BLACK)
        var x = 0.1f
        var y = 0.1f
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        for (i in 0 until n) {
            val nx = sin(a * y) - cos(b * x)
            val ny = sin(c * x) - cos(d * y)
            x = nx; y = ny
            xs[i] = x; ys[i] = y
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
        val pad = 0.06f
        val spanX = (maxX - minX).coerceAtLeast(1e-4f)
        val spanY = (maxY - minY).coerceAtLeast(1e-4f)
        val paint = Paint().apply {
            color = Color.argb(35, 255, 255, 255)
            style = Paint.Style.FILL
        }
        val sx = width * (1f - 2 * pad) / spanX
        val sy = height * (1f - 2 * pad) / spanY
        val ox = width * pad - minX * sx
        val oy = height * pad - minY * sy
        for (i in 0 until n) {
            canvas.drawPoint(xs[i] * sx + ox, ys[i] * sy + oy, paint)
        }
    }
}

/** Elementary cellular automaton (Rule 30 / 90 / 110 style) */
class CellularAutomatonGenerator : ProceduralGenerator {
    override val id = "cellular"
    override val name = "Cellular Automaton"
    override val description = "1D elementary CA evolved into 2D pattern"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("rule", "Rule (0-255)", ParameterType.INT, "30", 0f, 255f, 1f),
        ParameterDef("scale", "Cell Scale", ParameterType.INT, "2", 1f, 6f, 1f),
        ParameterDef("randomInit", "Random Seed Row", ParameterType.FLOAT, "0", 0f, 1f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val rule = params.getInt("rule", 30).coerceIn(0, 255)
        val scale = params.getInt("scale", 2).coerceIn(1, 8)
        val randomInit = params.getFloat("randomInit", 0f) >= 0.5f
        val cols = (width / scale).coerceAtLeast(8)
        val rows = (height / scale).coerceAtLeast(8)
        var row = BooleanArray(cols)
        if (randomInit) {
            for (i in row.indices) row[i] = random.nextFloat() < 0.5f
        } else {
            row[cols / 2] = true
        }
        val pixels = IntArray(width * height) { Color.BLACK }
        for (r in 0 until rows) {
            val y0 = r * scale
            for (c in 0 until cols) {
                if (!row[c]) continue
                val x0 = c * scale
                for (dy in 0 until scale) {
                    val yy = y0 + dy
                    if (yy >= height) break
                    for (dx in 0 until scale) {
                        val xx = x0 + dx
                        if (xx < width) pixels[yy * width + xx] = Color.WHITE
                    }
                }
            }
            val next = BooleanArray(cols)
            for (c in 0 until cols) {
                val left = if (row[(c - 1 + cols) % cols]) 1 else 0
                val mid = if (row[c]) 1 else 0
                val right = if (row[(c + 1) % cols]) 1 else 0
                val idx = (left shl 2) or (mid shl 1) or right
                next[c] = ((rule shr idx) and 1) == 1
            }
            row = next
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Simplified Gray-Scott reaction-diffusion (few iterations for mobile) */
class ReactionDiffusionGenerator : ProceduralGenerator {
    override val id = "reaction_diffusion"
    override val name = "Reaction Diffusion"
    override val description = "Gray-Scott reaction-diffusion patterns"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 9

    override val parameterSchema = listOf(
        ParameterDef("iterations", "Iterations", ParameterType.INT, "80", 20f, 200f, 10f),
        ParameterDef("feed", "Feed Rate", ParameterType.FLOAT, "0.055", 0.02f, 0.08f, 0.001f),
        ParameterDef("kill", "Kill Rate", ParameterType.FLOAT, "0.062", 0.04f, 0.08f, 0.001f),
        ParameterDef("scale", "Grid Scale", ParameterType.INT, "2", 1f, 4f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val iters = params.getInt("iterations", 80).coerceIn(10, 250)
        val feed = params.getFloat("feed", 0.055f)
        val kill = params.getFloat("kill", 0.062f)
        val scale = params.getInt("scale", 2).coerceIn(1, 4)
        val gw = (width / scale).coerceAtLeast(32)
        val gh = (height / scale).coerceAtLeast(32)
        val size = gw * gh
        var u = FloatArray(size) { 1f }
        var v = FloatArray(size) { 0f }
        // Seed blobs
        val blobs = 4 + random.nextInt(6)
        repeat(blobs) {
            val cx = random.nextInt(gw)
            val cy = random.nextInt(gh)
            val rad = 2 + random.nextInt(5)
            for (dy in -rad..rad) for (dx in -rad..rad) {
                if (dx * dx + dy * dy > rad * rad) continue
                val x = (cx + dx + gw) % gw
                val y = (cy + dy + gh) % gh
                val i = y * gw + x
                u[i] = 0.5f
                v[i] = 0.25f
            }
        }
        val Du = 1.0f
        val Dv = 0.5f
        val dt = 1.0f
        fun idx(x: Int, y: Int) = ((y + gh) % gh) * gw + ((x + gw) % gw)
        repeat(iters) {
            val u2 = FloatArray(size)
            val v2 = FloatArray(size)
            for (y in 0 until gh) {
                for (x in 0 until gw) {
                    val i = y * gw + x
                    val lapU = u[idx(x - 1, y)] + u[idx(x + 1, y)] + u[idx(x, y - 1)] + u[idx(x, y + 1)] - 4f * u[i]
                    val lapV = v[idx(x - 1, y)] + v[idx(x + 1, y)] + v[idx(x, y - 1)] + v[idx(x, y + 1)] - 4f * v[i]
                    val uvv = u[i] * v[i] * v[i]
                    u2[i] = (u[i] + (Du * lapU - uvv + feed * (1f - u[i])) * dt).coerceIn(0f, 1f)
                    v2[i] = (v[i] + (Dv * lapV + uvv - (kill + feed) * v[i]) * dt).coerceIn(0f, 1f)
                }
            }
            u = u2; v = v2
        }
        val pixels = IntArray(width * height) { Color.BLACK }
        for (y in 0 until height) {
            val gy = (y / scale).coerceIn(0, gh - 1)
            for (x in 0 until width) {
                val gx = (x / scale).coerceIn(0, gw - 1)
                val t = v[gy * gw + gx]
                val c = (t * 255f).toInt().coerceIn(0, 255)
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Circle packing with seeded radii */
class CirclePackingGenerator : ProceduralGenerator {
    override val id = "circle_packing"
    override val name = "Circle Packing"
    override val description = "Non-overlapping packed circles"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("count", "Circles", ParameterType.INT, "120", 20f, 400f, 10f),
        ParameterDef("minR", "Min Radius", ParameterType.FLOAT, "6", 2f, 30f, 1f),
        ParameterDef("maxR", "Max Radius", ParameterType.FLOAT, "40", 10f, 100f, 2f),
        ParameterDef("filled", "Filled", ParameterType.FLOAT, "0", 0f, 1f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val count = params.getInt("count", 120).coerceIn(10, 500)
        val minR = params.getFloat("minR", 6f)
        val maxR = params.getFloat("maxR", 40f).coerceAtLeast(minR + 1f)
        val filled = params.getFloat("filled", 0f) >= 0.5f
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = if (filled) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = 1.5f
            color = Color.WHITE
        }
        data class C(val x: Float, val y: Float, val r: Float)
        val placed = ArrayList<C>(count)
        var attempts = 0
        val maxAttempts = count * 80
        while (placed.size < count && attempts < maxAttempts) {
            attempts++
            val r = minR + random.nextFloat() * (maxR - minR)
            val x = r + random.nextFloat() * (width - 2 * r)
            val y = r + random.nextFloat() * (height - 2 * r)
            var ok = true
            for (p in placed) {
                if (hypot(x - p.x, y - p.y) < r + p.r + 1f) {
                    ok = false
                    break
                }
            }
            if (ok) {
                placed.add(C(x, y, r))
                canvas.drawCircle(x, y, r, paint)
            }
        }
    }
}

/** Kaleidoscope / radial symmetry mirror of noise strokes */
class KaleidoscopeGenerator : ProceduralGenerator {
    override val id = "kaleidoscope"
    override val name = "Kaleidoscope"
    override val description = "Radial symmetry strokes"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("segments", "Segments", ParameterType.INT, "8", 3f, 16f, 1f),
        ParameterDef("strokes", "Strokes", ParameterType.INT, "40", 10f, 120f, 5f),
        ParameterDef("complexity", "Complexity", ParameterType.INT, "6", 2f, 14f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val segments = params.getInt("segments", 8).coerceIn(2, 24)
        val strokes = params.getInt("strokes", 40).coerceIn(5, 150)
        val complexity = params.getInt("complexity", 6).coerceIn(2, 20)
        canvas.drawColor(Color.BLACK)
        val cx = width / 2f
        val cy = height / 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            color = Color.WHITE
            strokeCap = Paint.Cap.ROUND
        }
        val angleStep = (2.0 * PI / segments).toFloat()
        for (s in 0 until strokes) {
            val pts = Array(complexity) {
                floatArrayOf(random.nextFloat() * width * 0.45f, random.nextFloat() * height * 0.45f)
            }
            for (seg in 0 until segments) {
                val a = seg * angleStep
                val cosA = cos(a)
                val sinA = sin(a)
                for (i in 0 until complexity - 1) {
                    val x1 = pts[i][0]
                    val y1 = pts[i][1]
                    val x2 = pts[i + 1][0]
                    val y2 = pts[i + 1][1]
                    // rotate
                    val rx1 = cx + x1 * cosA - y1 * sinA
                    val ry1 = cy + x1 * sinA + y1 * cosA
                    val rx2 = cx + x2 * cosA - y2 * sinA
                    val ry2 = cy + x2 * sinA + y2 * cosA
                    canvas.drawLine(rx1, ry1, rx2, ry2, paint)
                    // mirror
                    val mx1 = cx - x1 * cosA - y1 * sinA
                    val my1 = cy - x1 * sinA + y1 * cosA
                    val mx2 = cx - x2 * cosA - y2 * sinA
                    val my2 = cy - x2 * sinA + y2 * cosA
                    canvas.drawLine(mx1, my1, mx2, my2, paint)
                }
            }
        }
    }
}

/** Zone plate / Fresnel diffraction rings */
class ZonePlateGenerator : ProceduralGenerator {
    override val id = "zone_plate"
    override val name = "Zone Plate"
    override val description = "Fresnel zone plate interference rings"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("frequency", "Frequency", ParameterType.FLOAT, "40", 5f, 120f, 1f),
        ParameterDef("contrast", "Contrast", ParameterType.FLOAT, "1.0", 0.3f, 2f, 0.1f),
        ParameterDef("offsetX", "Center X", ParameterType.FLOAT, "0.5", 0.2f, 0.8f, 0.05f),
        ParameterDef("offsetY", "Center Y", ParameterType.FLOAT, "0.5", 0.2f, 0.8f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val freq = params.getFloat("frequency", 40f)
        val contrast = params.getFloat("contrast", 1f)
        val ox = params.getFloat("offsetX", 0.5f) * width
        val oy = params.getFloat("offsetY", 0.5f) * height
        val pixels = IntArray(width * height)
        val invMax = 1f / hypot(width.toFloat(), height.toFloat())
        for (y in 0 until height) {
            for (x in 0 until width) {
                val r = hypot(x - ox, y - oy) * invMax
                val v = (sin(r * r * freq * PI.toFloat()) * contrast + 1f) * 0.5f
                val c = (v * 255f).toInt().coerceIn(0, 255)
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Ink diffusion / organic blot */
class InkBlotGenerator : ProceduralGenerator {
    override val id = "ink_blot"
    override val name = "Ink Blot"
    override val description = "Symmetric ink-blot organic shapes"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("blobs", "Blobs", ParameterType.INT, "5", 1f, 12f, 1f),
        ParameterDef("smooth", "Smoothness", ParameterType.FLOAT, "0.35", 0.1f, 0.8f, 0.05f),
        ParameterDef("threshold", "Threshold", ParameterType.FLOAT, "0.45", 0.2f, 0.7f, 0.02f),
        ParameterDef("mirror", "Mirror", ParameterType.FLOAT, "1", 0f, 1f, 1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val blobs = params.getInt("blobs", 5).coerceIn(1, 16)
        val smooth = params.getFloat("smooth", 0.35f)
        val threshold = params.getFloat("threshold", 0.45f)
        val mirror = params.getFloat("mirror", 1f) >= 0.5f
        data class Blob(val x: Float, val y: Float, val r: Float, val s: Float)
        val list = List(blobs) {
            Blob(
                random.nextFloat() * width * 0.5f + width * 0.1f,
                random.nextFloat() * height,
                40f + random.nextFloat() * min(width, height) * 0.25f,
                0.6f + random.nextFloat() * 1.2f
            )
        }
        val pixels = IntArray(width * height) { Color.BLACK }
        val sigma = smooth * min(width, height) * 0.15f + 1f
        for (y in 0 until height) {
            for (x in 0 until width) {
                var field = 0f
                for (b in list) {
                    val dx = x - b.x
                    val dy = y - b.y
                    field += b.s * exp(-(dx * dx + dy * dy) / (2f * b.r * b.r))
                    if (mirror) {
                        val dx2 = (width - 1 - x) - b.x
                        field += b.s * exp(-(dx2 * dx2 + dy * dy) / (2f * b.r * b.r))
                    }
                }
                // soft edge
                val t = ((field - threshold) / (sigma * 0.01f + 0.15f) + 0.5f).coerceIn(0f, 1f)
                val c = (t * 255f).toInt()
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}
