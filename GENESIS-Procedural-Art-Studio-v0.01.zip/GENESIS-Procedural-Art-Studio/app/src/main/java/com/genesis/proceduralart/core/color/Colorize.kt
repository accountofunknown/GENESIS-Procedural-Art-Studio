package com.genesis.proceduralart.core.color

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.floor

/**
 * Post-process grayscale procedural output into colour using intensity → palette mapping.
 * Mode 0 = monochrome (no change).
 */
object Colorize {

    val modeNames = listOf(
        "Mono",
        "Spectrum",
        "Heat",
        "Neon",
        "Ocean",
        "Forest",
        "Sunset",
        "Ice"
    )

    /**
     * @param mode 0..7
     * @param hueShift 0..360 degrees, rotates spectrum-based palettes
     * @param saturation 0..1
     * @param brightness 0..1 multiplier for non-black pixels
     */
    fun apply(
        src: Bitmap,
        mode: Int,
        hueShift: Float = 0f,
        saturation: Float = 1f,
        brightness: Float = 1f
    ): Bitmap {
        if (mode <= 0) return src
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        val sat = saturation.coerceIn(0f, 1.5f)
        val bri = brightness.coerceIn(0.2f, 2f)
        val shift = ((hueShift % 360f) + 360f) % 360f

        for (i in pixels.indices) {
            val p = pixels[i]
            val a = Color.alpha(p)
            if (a == 0) continue
            // Luminance of source (art is typically white-on-black)
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val t = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            if (t < 0.004f) {
                pixels[i] = Color.BLACK
                continue
            }
            val rgb = sample(mode, t, shift, sat, bri)
            pixels[i] = Color.argb(a, Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        }
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    private fun sample(mode: Int, t: Float, hueShift: Float, sat: Float, bri: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val hsv = FloatArray(3)
        when (mode) {
            1 -> { // Spectrum — rainbow by intensity
                hsv[0] = (tt * 300f + hueShift) % 360f
                hsv[1] = sat
                hsv[2] = (0.25f + 0.75f * tt) * bri
            }
            2 -> { // Heat — black → red → yellow → white
                hsv[0] = (tt * 60f + hueShift * 0.15f) % 360f
                hsv[1] = (1f - tt * 0.7f) * sat
                hsv[2] = tt * bri
            }
            3 -> { // Neon — high sat cyan/magenta
                hsv[0] = (180f + tt * 120f + hueShift) % 360f
                hsv[1] = (0.7f + 0.3f * tt) * sat
                hsv[2] = (0.4f + 0.6f * tt) * bri
            }
            4 -> { // Ocean — deep blue → cyan → white
                hsv[0] = (200f + tt * 40f + hueShift * 0.2f) % 360f
                hsv[1] = (1f - tt * 0.85f) * sat
                hsv[2] = (0.15f + 0.85f * tt) * bri
            }
            5 -> { // Forest — dark green → lime
                hsv[0] = (100f + tt * 40f + hueShift * 0.2f) % 360f
                hsv[1] = (0.9f - tt * 0.4f) * sat
                hsv[2] = (0.12f + 0.88f * tt) * bri
            }
            6 -> { // Sunset — purple → orange → gold
                hsv[0] = (280f - tt * 80f + hueShift * 0.2f + 360f) % 360f
                hsv[1] = (0.85f - tt * 0.3f) * sat
                hsv[2] = (0.2f + 0.8f * tt) * bri
            }
            7 -> { // Ice — blue → cyan → white
                hsv[0] = (190f + tt * 30f + hueShift * 0.15f) % 360f
                hsv[1] = (0.55f * (1f - tt)) * sat
                hsv[2] = (0.3f + 0.7f * tt) * bri
            }
            else -> return Color.rgb(
                (tt * 255 * bri).toInt().coerceIn(0, 255),
                (tt * 255 * bri).toInt().coerceIn(0, 255),
                (tt * 255 * bri).toInt().coerceIn(0, 255)
            )
        }
        hsv[1] = hsv[1].coerceIn(0f, 1f)
        hsv[2] = hsv[2].coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    /** Quick solid stroke colour from hue (for optional future generator use). */
    fun solidFromHue(hue: Float, sat: Float = 0.85f, value: Float = 1f): Int {
        val hsv = floatArrayOf(((hue % 360f) + 360f) % 360f, sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
        return Color.HSVToColor(hsv)
    }
}
