package com.genesis.proceduralart.core.color

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Post-process grayscale procedural output into colour using intensity → palette mapping.
 * Mode 0 = monochrome. Mode 8 = custom multi-stop palette.
 */
object Colorize {

    val modeNames = listOf(
        "Mono",
        "Spectrum",
        "Heat",
        "Neon",
        "Ocean",
        "Forest",
        "Sunset",
        "Ice",
        "Custom"
    )

    const val MODE_CUSTOM = 8

    /** Default 4-stop custom palette (blue → cyan → magenta → gold). */
    val defaultCustomColors: List<Int> = listOf(
        Color.rgb(20, 40, 180),
        Color.rgb(0, 220, 200),
        Color.rgb(255, 40, 160),
        Color.rgb(255, 200, 40)
    )

    /** Built-in multi-colour preset packs for one-tap apply. */
    val presetPalettes: List<Pair<String, List<Int>>> = listOf(
        "Neon Pop" to listOf(Color.rgb(255, 0, 128), Color.rgb(0, 255, 200), Color.rgb(180, 0, 255), Color.rgb(255, 240, 0)),
        "Fire" to listOf(Color.rgb(40, 0, 0), Color.rgb(200, 20, 0), Color.rgb(255, 120, 0), Color.rgb(255, 240, 180)),
        "Aurora" to listOf(Color.rgb(10, 20, 60), Color.rgb(0, 180, 120), Color.rgb(80, 220, 255), Color.rgb(200, 120, 255)),
        "Candy" to listOf(Color.rgb(255, 100, 150), Color.rgb(255, 180, 200), Color.rgb(160, 120, 255), Color.rgb(100, 200, 255)),
        "Gold" to listOf(Color.rgb(40, 20, 0), Color.rgb(180, 100, 20), Color.rgb(255, 190, 50), Color.rgb(255, 250, 220)),
        "Mono Blue" to listOf(Color.rgb(0, 10, 40), Color.rgb(20, 60, 140), Color.rgb(80, 140, 220), Color.rgb(200, 230, 255))
    )

    /**
     * @param mode 0..8
     * @param customColors used when mode == MODE_CUSTOM (2–8 ARGB colours, low→high intensity)
     */
    fun apply(
        src: Bitmap,
        mode: Int,
        hueShift: Float = 0f,
        saturation: Float = 1f,
        brightness: Float = 1f,
        customColors: List<Int> = defaultCustomColors
    ): Bitmap {
        if (mode <= 0) return src
        val w = src.width
        val h = src.height
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)
        val sat = saturation.coerceIn(0f, 1.5f)
        val bri = brightness.coerceIn(0.2f, 2f)
        val shift = ((hueShift % 360f) + 360f) % 360f
        val stops = if (mode == MODE_CUSTOM) {
            (if (customColors.size >= 2) customColors else defaultCustomColors).map { adjustColor(it, sat, bri) }
        } else null

        for (i in pixels.indices) {
            val p = pixels[i]
            val a = Color.alpha(p)
            if (a == 0) continue
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val t = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            if (t < 0.004f) {
                pixels[i] = Color.BLACK
                continue
            }
            val rgb = if (stops != null) {
                lerpStops(stops, t)
            } else {
                sample(mode, t, shift, sat, bri)
            }
            pixels[i] = Color.argb(a, Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        }
        val out = if (src.isMutable) src else src.copy(Bitmap.Config.ARGB_8888, true)
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    /** Linear blend across colour stops by intensity t ∈ [0,1]. */
    fun lerpStops(stops: List<Int>, t: Float): Int {
        if (stops.isEmpty()) return Color.WHITE
        if (stops.size == 1) return stops[0]
        val tt = t.coerceIn(0f, 1f)
        val seg = (stops.size - 1) * tt
        val i = seg.toInt().coerceIn(0, stops.size - 2)
        val f = seg - i
        return lerpColor(stops[i], stops[i + 1], f)
    }

    fun lerpColor(c0: Int, c1: Int, f: Float): Int {
        val t = f.coerceIn(0f, 1f)
        val r = (Color.red(c0) + (Color.red(c1) - Color.red(c0)) * t).toInt().coerceIn(0, 255)
        val g = (Color.green(c0) + (Color.green(c1) - Color.green(c0)) * t).toInt().coerceIn(0, 255)
        val b = (Color.blue(c0) + (Color.blue(c1) - Color.blue(c0)) * t).toInt().coerceIn(0, 255)
        val a = (Color.alpha(c0) + (Color.alpha(c1) - Color.alpha(c0)) * t).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun adjustColor(c: Int, sat: Float, bri: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = (hsv[1] * sat).coerceIn(0f, 1f)
        hsv[2] = (hsv[2] * bri).coerceIn(0f, 1f)
        return Color.HSVToColor(Color.alpha(c), hsv)
    }

    private fun sample(mode: Int, t: Float, hueShift: Float, sat: Float, bri: Float): Int {
        val tt = t.coerceIn(0f, 1f)
        val hsv = FloatArray(3)
        when (mode) {
            1 -> {
                hsv[0] = (tt * 300f + hueShift) % 360f
                hsv[1] = sat.coerceIn(0f, 1f)
                hsv[2] = ((0.25f + 0.75f * tt) * bri).coerceIn(0f, 1f)
            }
            2 -> {
                hsv[0] = (tt * 60f + hueShift * 0.15f) % 360f
                hsv[1] = ((1f - tt * 0.7f) * sat).coerceIn(0f, 1f)
                hsv[2] = (tt * bri).coerceIn(0f, 1f)
            }
            3 -> {
                hsv[0] = (180f + tt * 120f + hueShift) % 360f
                hsv[1] = ((0.7f + 0.3f * tt) * sat).coerceIn(0f, 1f)
                hsv[2] = ((0.4f + 0.6f * tt) * bri).coerceIn(0f, 1f)
            }
            4 -> {
                hsv[0] = (200f + tt * 40f + hueShift * 0.2f) % 360f
                hsv[1] = ((1f - tt * 0.85f) * sat).coerceIn(0f, 1f)
                hsv[2] = ((0.15f + 0.85f * tt) * bri).coerceIn(0f, 1f)
            }
            5 -> {
                hsv[0] = (100f + tt * 40f + hueShift * 0.2f) % 360f
                hsv[1] = ((0.9f - tt * 0.4f) * sat).coerceIn(0f, 1f)
                hsv[2] = ((0.12f + 0.88f * tt) * bri).coerceIn(0f, 1f)
            }
            6 -> {
                hsv[0] = (280f - tt * 80f + hueShift * 0.2f + 360f) % 360f
                hsv[1] = ((0.85f - tt * 0.3f) * sat).coerceIn(0f, 1f)
                hsv[2] = ((0.2f + 0.8f * tt) * bri).coerceIn(0f, 1f)
            }
            7 -> {
                hsv[0] = (190f + tt * 30f + hueShift * 0.15f) % 360f
                hsv[1] = ((0.55f * (1f - tt)) * sat).coerceIn(0f, 1f)
                hsv[2] = ((0.3f + 0.7f * tt) * bri).coerceIn(0f, 1f)
            }
            else -> return Color.rgb(
                (tt * 255 * bri).toInt().coerceIn(0, 255),
                (tt * 255 * bri).toInt().coerceIn(0, 255),
                (tt * 255 * bri).toInt().coerceIn(0, 255)
            )
        }
        return Color.HSVToColor(hsv)
    }

    fun solidFromHue(hue: Float, sat: Float = 0.85f, value: Float = 1f): Int {
        val hsv = floatArrayOf(((hue % 360f) + 360f) % 360f, sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
        return Color.HSVToColor(hsv)
    }
}
