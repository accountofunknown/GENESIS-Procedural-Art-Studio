package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Paint
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom

/**
 * Common interface for all procedural generators.
 * Implementations must be pure with respect to the provided seed + parameters.
 */
interface ProceduralGenerator {
    val id: String
    val name: String
    val description: String
    val category: String
    val version: Int
    val parameterSchema: List<ParameterDef>
    val supportsGpu: Boolean get() = false
    val estimatedCost: Int get() = 1 // relative 1..10

    fun defaultParameters(): ParameterValues {
        val map = parameterSchema.associate { it.key to it.defaultValue }
        return ParameterValues(map)
    }

    fun validate(params: ParameterValues): String? = null

    /**
     * Render into the provided Canvas at the given size.
     * Must not touch the UI thread; caller is responsible for background execution.
     */
    fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    )
}

object GeneratorRegistry {
    private val generators = linkedMapOf<String, ProceduralGenerator>()

    fun register(generator: ProceduralGenerator) {
        generators[generator.id] = generator
    }

    fun get(id: String): ProceduralGenerator? = generators[id]

    fun all(): List<ProceduralGenerator> = generators.values.toList()

    fun byCategory(category: String): List<ProceduralGenerator> =
        generators.values.filter { it.category.equals(category, ignoreCase = true) }

    fun categories(): List<String> =
        generators.values.map { it.category }.distinct().sorted()
}
