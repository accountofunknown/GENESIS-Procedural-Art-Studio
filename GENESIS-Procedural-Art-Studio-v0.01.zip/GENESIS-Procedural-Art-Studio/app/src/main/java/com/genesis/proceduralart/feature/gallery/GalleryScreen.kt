package com.genesis.proceduralart.feature.gallery

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.ui.theme.*

@Composable
fun GalleryScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Gallery", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
            Spacer(Modifier.height(12.dp))
            Text(
                "Saved projects will appear here.\nProject persistence is file-based in v0.01.",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftGray
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Open the Create tab, generate, then use Save.",
                style = MaterialTheme.typography.labelMedium,
                color = MidGray
            )
        }
    }
}
