package com.genesis.proceduralart.feature.gallery

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.core.model.Project
import com.genesis.proceduralart.core.storage.ProjectRepository
import com.genesis.proceduralart.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GalleryScreen(onOpenProject: (String) -> Unit = {}) {
    val context = LocalContext.current
    val repo = remember { ProjectRepository(context) }
    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    fun reload() {
        scope.launch {
            loading = true
            projects = repo.listProjects()
            loading = false
        }
    }

    LaunchedEffect(Unit) { reload() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
    ) {
        Text("Gallery", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text(
            if (loading) "Loading…" else "${projects.size} saved project(s)",
            style = MaterialTheme.typography.bodyMedium,
            color = SoftGray
        )
        Spacer(Modifier.height(12.dp))

        if (!loading && projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No saved projects yet", color = SoftGray)
                    Spacer(Modifier.height(8.dp))
                    Text("Open Create, generate, then tap Save", style = MaterialTheme.typography.labelMedium, color = MidGray)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(140.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(projects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        thumbPath = repo.thumbnailFile(project.id).absolutePath,
                        onOpen = { onOpenProject(project.id) },
                        onDelete = {
                            scope.launch {
                                repo.deleteProject(project.id)
                                reload()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProjectCard(
    project: Project,
    thumbPath: String,
    onOpen: () -> Unit,
    onDelete: () -> Unit
) {
    val bitmap = remember(thumbPath) {
        runCatching { BitmapFactory.decodeFile(thumbPath) }.getOrNull()
    }
    val date = remember(project.modifiedAt) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(project.modifiedAt))
    }

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Charcoal)
            .clickable(onClick = onOpen)
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(8.dp))
                .background(NearBlack),
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = project.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text("No thumb", color = MidGray, style = MaterialTheme.typography.labelSmall)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(project.name, style = MaterialTheme.typography.titleMedium, color = OffWhite, maxLines = 1)
        Text(date, style = MaterialTheme.typography.labelSmall, color = SoftGray)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = SoftGray)
            }
        }
    }
}
