package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class ConcentricCirclesGenerator : ProceduralGenerator {
    override val id = "concentric_circles"
    override val name = "Concentric Circles"
    override val description = "Nested circles with optional rotation and spiral offset"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 2

    override val parameterSchema = listOf(
        ParameterDef("count", "Circle Count", ParameterType.INT, "24", 3f, 80f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.5", 0.5f, 8f, 0.1f),
        ParameterDef("spiral", "Spiral Offset", ParameterType.FLOAT, "0.0", 0f, 1f, 0.01f),
        ParameterDef("rotation", "Rotation (deg)", ParameterType.FLOAT, "0", 0f, 360f, 1f),
        ParameterDef("color", "Stroke Color", ParameterType.COLOR, "0xFFFFFFFF")
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val count = params.getInt("count", 24).coerceIn(3, 80)
        val lineWidth = params.getFloat("lineWidth", 1.5f)
        val spiral = params.getFloat("spiral", 0f)
        val rotation = params.getFloat("rotation", 0f) * (PI / 180.0).toFloat()
        val color = params.values["color"]?.removePrefix("0x")?.toLongOrNull(16)?.toInt()
            ?: Color.WHITE

        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f * 0.92f

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lineWidth
            this.color = color
        }

        for (i in 1..count) {
            val t = i / count.toFloat()
            val r = maxR * t
            val angle = rotation + spiral * t * 2f * PI.toFloat()
            val ox = cos(angle) * spiral * 8f
            val oy = sin(angle) * spiral * 8f
            canvas.drawCircle(cx + ox, cy + oy, r, paint)
        }
    }
}

class RadialMandalaGenerator : ProceduralGenerator {
    override val id = "radial_mandala"
    override val name = "Radial Mandala"
    override val description = "Symmetric radial geometric pattern"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("symmetry", "Symmetry", ParameterType.INT, "8", 3f, 24f, 1f),
        ParameterDef("rings", "Rings", ParameterType.INT, "6", 2f, 16f, 1f),
        ParameterDef("petals", "Petals per ring", ParameterType.INT, "12", 4f, 32f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.2", 0.5f, 6f, 0.1f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val symmetry = params.getInt("symmetry", 8).coerceIn(3, 24)
        val rings = params.getInt("rings", 6).coerceIn(2, 16)
        val petals = params.getInt("petals", 12).coerceIn(4, 32)
        val lineWidth = params.getFloat("lineWidth", 1.2f)

        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f * 0.9f

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lineWidth
            color = Color.WHITE
        }

        for (ring in 1..rings) {
            val r = maxR * ring / rings
            canvas.drawCircle(cx, cy, r, paint)

            val angleStep = (2 * PI / symmetry).toFloat()
            for (s in 0 until symmetry) {
                val base = s * angleStep
                for (p in 0 until petals / symmetry) {
                    val a = base + p * (angleStep / (petals / symmetry + 1))
                    val x1 = cx + cos(a) * (r * 0.4f)
                    val y1 = cy + sin(a) * (r * 0.4f)
                    val x2 = cx + cos(a) * r
                    val y2 = cy + sin(a) * r
                    canvas.drawLine(x1, y1, x2, y2, paint)
                }
            }
        }
    }
}

class GridLinesGenerator : ProceduralGenerator {
    override val id = "grid_lines"
    override val name = "Grid Lines"
    override val description = "Geometric line grid with optional perspective tilt"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 2

    override val parameterSchema = listOf(
        ParameterDef("cols", "Columns", ParameterType.INT, "12", 2f, 40f, 1f),
        ParameterDef("rows", "Rows", ParameterType.INT, "12", 2f, 40f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.0", 0.3f, 5f, 0.1f),
        ParameterDef("jitter", "Jitter", ParameterType.FLOAT, "0.0", 0f, 0.3f, 0.01f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val cols = params.getInt("cols", 12).coerceIn(2, 40)
        val rows = params.getInt("rows", 12).coerceIn(2, 40)
        val lineWidth = params.getFloat("lineWidth", 1f)
        val jitter = params.getFloat("jitter", 0f)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lineWidth
            color = Color.WHITE
        }

        val dx = width.toFloat() / cols
        val dy = height.toFloat() / rows

        for (c in 0..cols) {
            val x = c * dx + if (jitter > 0) (random.nextFloat() - 0.5f) * dx * jitter else 0f
            canvas.drawLine(x, 0f, x, height.toFloat(), paint)
        }
        for (r in 0..rows) {
            val y = r * dy + if (jitter > 0) (random.nextFloat() - 0.5f) * dy * jitter else 0f
            canvas.drawLine(0f, y, width.toFloat(), y, paint)
        }
    }
}

class RecursiveSubdivisionGenerator : ProceduralGenerator {
    override val id = "recursive_subdivision"
    override val name = "Recursive Subdivision"
    override val description = "Recursive geometric space subdivision"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("depth", "Depth", ParameterType.INT, "5", 1f, 8f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.0", 0.4f, 4f, 0.1f),
        ParameterDef("splitBias", "Split Bias", ParameterType.FLOAT, "0.5", 0.2f, 0.8f, 0.05f)
    )

    override fun render(
        canvas: Canvas,
        width: Int,
        height: Int,
        seed: Long,
        params: ParameterValues,
        random: SeededRandom
    ) {
        val depth = params.getInt("depth", 5).coerceIn(1, 8)
        val lineWidth = params.getFloat("lineWidth", 1f)
        val bias = params.getFloat("splitBias", 0.5f)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = lineWidth
            color = Color.WHITE
        }

        fun subdivide(x: Float, y: Float, w: Float, h: Float, d: Int) {
            if (d <= 0 || w < 4f || h < 4f) return
            canvas.drawRect(x, y, x + w, y + h, paint)
            val horizontal = random.nextBoolean()
            if (horizontal) {
                val split = h * (bias + (random.nextFloat() - 0.5f) * 0.3f).coerceIn(0.2f, 0.8f)
                subdivide(x, y, w, split, d - 1)
                subdivide(x, y + split, w, h - split, d - 1)
            } else {
                val split = w * (bias + (random.nextFloat() - 0.5f) * 0.3f).coerceIn(0.2f, 0.8f)
                subdivide(x, y, split, h, d - 1)
                subdivide(x + split, y, w - split, h, d - 1)
            }
        }

        subdivide(0f, 0f, width.toFloat(), height.toFloat(), depth)
    }
}
