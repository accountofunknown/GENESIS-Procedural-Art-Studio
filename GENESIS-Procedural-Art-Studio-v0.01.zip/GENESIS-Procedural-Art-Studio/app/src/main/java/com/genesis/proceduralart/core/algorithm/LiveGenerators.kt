package com.genesis.proceduralart.core.algorithm

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import com.genesis.proceduralart.core.model.ParameterDef
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.core.model.ParameterValues
import com.genesis.proceduralart.core.random.SeededRandom
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Julia-like rational map attractor */
class HopalongAttractorGenerator : ProceduralGenerator {
    override val id = "hopalong"
    override val name = "Hopalong Attractor"
    override val description = "Martin hopalong quadratic attractor"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 6

    override val parameterSchema = listOf(
        ParameterDef("points", "Points", ParameterType.INT, "100000", 20000f, 250000f, 5000f),
        ParameterDef("a", "A", ParameterType.FLOAT, "0.4", -2f, 2f, 0.05f),
        ParameterDef("b", "B", ParameterType.FLOAT, "1.0", -2f, 2f, 0.05f),
        ParameterDef("c", "C", ParameterType.FLOAT, "0.0", -2f, 2f, 0.05f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val n = params.getInt("points", 100000).coerceIn(5000, 300000)
        val a = params.getFloat("a", 0.4f)
        val b = params.getFloat("b", 1f)
        val c = params.getFloat("c", 0f)
        canvas.drawColor(Color.BLACK)
        var x = 0f
        var y = 0f
        var minX = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        val xs = FloatArray(n); val ys = FloatArray(n)
        for (i in 0 until n) {
            val nx = y - 1f - sqrt(abs(b * x - c)) * if (x < 0) -1f else 1f
            val ny = a - x
            x = nx; y = ny
            xs[i] = x; ys[i] = y
            if (x < minX) minX = x; if (x > maxX) maxX = x
            if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val pad = 0.08f
        val spanX = (maxX - minX).coerceAtLeast(1e-4f)
        val spanY = (maxY - minY).coerceAtLeast(1e-4f)
        val sx = width * (1f - 2 * pad) / spanX
        val sy = height * (1f - 2 * pad) / spanY
        val ox = width * pad - minX * sx
        val oy = height * pad - minY * sy
        val paint = Paint().apply { color = Color.argb(40, 255, 255, 255); style = Paint.Style.FILL }
        for (i in 0 until n) canvas.drawPoint(xs[i] * sx + ox, ys[i] * sy + oy, paint)
    }
}

/** Spiral / Archimedean with modulation */
class SpiralWeaveGenerator : ProceduralGenerator {
    override val id = "spiral_weave"
    override val name = "Spiral Weave"
    override val description = "Modulated Archimedean spiral weave"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("turns", "Turns", ParameterType.FLOAT, "8", 2f, 24f, 0.5f),
        ParameterDef("arms", "Arms", ParameterType.INT, "3", 1f, 8f, 1f),
        ParameterDef("mod", "Modulation", ParameterType.FLOAT, "0.15", 0f, 0.5f, 0.02f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.5", 0.5f, 4f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val turns = params.getFloat("turns", 8f)
        val arms = params.getInt("arms", 3).coerceIn(1, 12)
        val mod = params.getFloat("mod", 0.15f)
        val lw = params.getFloat("lineWidth", 1.5f)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lw; color = Color.WHITE; strokeCap = Paint.Cap.ROUND
        }
        val cx = width / 2f; val cy = height / 2f
        val maxR = min(width, height) * 0.48f
        val steps = (turns * 400).toInt().coerceIn(200, 8000)
        for (arm in 0 until arms) {
            val path = Path()
            val phase = arm * (2f * PI.toFloat() / arms) + ((seed and 0xFFFFL).toFloat() / 65535f) * 6.2832f
            for (i in 0..steps) {
                val t = i / steps.toFloat()
                val ang = t * turns * 2f * PI.toFloat() + phase
                val r = t * maxR * (1f + mod * sin(ang * 5f))
                val x = cx + cos(ang) * r
                val y = cy + sin(ang) * r
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }
    }
}

/** Waveform terrain / ridged noise lines */
class RidgedTerrainGenerator : ProceduralGenerator {
    override val id = "ridged_terrain"
    override val name = "Ridged Terrain"
    override val description = "Ridged multi-octave noise terrain slices"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 5

    override val parameterSchema = listOf(
        ParameterDef("lines", "Lines", ParameterType.INT, "48", 10f, 120f, 2f),
        ParameterDef("octaves", "Octaves", ParameterType.INT, "4", 1f, 6f, 1f),
        ParameterDef("amp", "Amplitude", ParameterType.FLOAT, "0.35", 0.1f, 0.8f, 0.05f),
        ParameterDef("scale", "Scale", ParameterType.FLOAT, "3.5", 1f, 10f, 0.25f)
    )

    private fun hash(ix: Int, seed: Long): Float {
        var n = ix * 374761393 + seed.toInt() * 668265263
        n = (n xor (n ushr 13)) * 1274126177
        return ((n xor (n ushr 16)) and 0xFFFF) / 65535f
    }

    private fun noise1(x: Float, seed: Long): Float {
        val i = floor(x).toInt()
        val f = x - i
        val u = f * f * (3f - 2f * f)
        return hash(i, seed) * (1 - u) + hash(i + 1, seed) * u
    }

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val lines = params.getInt("lines", 48).coerceIn(5, 150)
        val octaves = params.getInt("octaves", 4).coerceIn(1, 7)
        val amp = params.getFloat("amp", 0.35f)
        val scale = params.getFloat("scale", 3.5f)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.2f; color = Color.WHITE
        }
        val gap = height.toFloat() / (lines + 1)
        for (li in 0 until lines) {
            val baseY = gap * (li + 1)
            val path = Path()
            var first = true
            for (x in 0 until width step 2) {
                var n = 0f; var a = 1f; var f = scale; var norm = 0f
                repeat(octaves) {
                    val sample = 1f - abs(noise1(x / width.toFloat() * f + li * 0.37f, seed + it * 17L) * 2f - 1f)
                    n += sample * a
                    norm += a
                    a *= 0.5f; f *= 2.1f
                }
                n = (n / norm) * amp * height * 0.5f
                val y = baseY - n
                if (first) { path.moveTo(x.toFloat(), y); first = false } else path.lineTo(x.toFloat(), y)
            }
            canvas.drawPath(path, paint)
        }
    }
}

/** Hexagonal grid mosaic */
class HexGridGenerator : ProceduralGenerator {
    override val id = "hex_grid"
    override val name = "Hex Grid"
    override val description = "Hexagonal tiling with seeded fill"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 4

    override val parameterSchema = listOf(
        ParameterDef("size", "Hex Size", ParameterType.FLOAT, "28", 10f, 60f, 1f),
        ParameterDef("filled", "Fill Chance", ParameterType.FLOAT, "0.45", 0f, 1f, 0.05f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.2", 0.5f, 3f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val size = params.getFloat("size", 28f).coerceIn(8f, 80f)
        val fillChance = params.getFloat("filled", 0.45f)
        val lw = params.getFloat("lineWidth", 1.2f)
        canvas.drawColor(Color.BLACK)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lw; color = Color.WHITE
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = Color.argb(180, 255, 255, 255)
        }
        val h = size * sqrt(3f)
        val w = size * 1.5f
        var row = 0
        var y = 0f
        while (y < height + h) {
            var col = 0
            var x = if (row % 2 == 0) 0f else size * 0.75f
            while (x < width + size) {
                val path = Path()
                for (i in 0..5) {
                    val ang = (PI / 3.0 * i).toFloat()
                    val px = x + cos(ang) * size
                    val py = y + sin(ang) * size
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                val roll = random.nextFloat()
                if (roll < fillChance * 0.5f) canvas.drawPath(path, fill)
                canvas.drawPath(path, stroke)
                x += size * 1.5f
                col++
            }
            y += h * 0.5f
            row++
        }
    }
}

/** Quadratic map / logistic bifurcation cloud */
class LogisticMapGenerator : ProceduralGenerator {
    override val id = "logistic_map"
    override val name = "Logistic Map"
    override val description = "Logistic bifurcation diagram"
    override val category = "Fractal"
    override val version = 1
    override val estimatedCost = 7

    override val parameterSchema = listOf(
        ParameterDef("rMin", "R Min", ParameterType.FLOAT, "2.5", 1f, 3.5f, 0.05f),
        ParameterDef("rMax", "R Max", ParameterType.FLOAT, "4.0", 3.5f, 4f, 0.01f),
        ParameterDef("iters", "Warmup+Plot", ParameterType.INT, "200", 80f, 400f, 10f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val rMin = params.getFloat("rMin", 2.5f)
        val rMax = params.getFloat("rMax", 4f).coerceAtLeast(rMin + 0.05f)
        val iters = params.getInt("iters", 200).coerceIn(50, 500)
        val warmup = iters / 2
        canvas.drawColor(Color.BLACK)
        val paint = Paint().apply { color = Color.argb(50, 255, 255, 255) }
        for (px in 0 until width) {
            val r = rMin + (rMax - rMin) * (px / width.toFloat())
            var x = 0.5f + ((seed and 0xFFFFL).toFloat() / 65535f) * 0.05f
            repeat(warmup) { x = r * x * (1f - x) }
            repeat(iters - warmup) {
                x = r * x * (1f - x)
                val py = ((1f - x) * (height - 1)).toInt().coerceIn(0, height - 1)
                canvas.drawPoint(px.toFloat(), py.toFloat(), paint)
            }
        }
    }
}

/** Concentric star / polar rose */
class PolarRoseGenerator : ProceduralGenerator {
    override val id = "polar_rose"
    override val name = "Polar Rose"
    override val description = "Rhodonea polar rose curves"
    override val category = "Geometric"
    override val version = 1
    override val estimatedCost = 2

    override val parameterSchema = listOf(
        ParameterDef("k", "Petals (k)", ParameterType.FLOAT, "5", 1f, 12f, 0.5f),
        ParameterDef("layers", "Layers", ParameterType.INT, "6", 1f, 16f, 1f),
        ParameterDef("lineWidth", "Line Width", ParameterType.FLOAT, "1.4", 0.5f, 4f, 0.1f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val k = params.getFloat("k", 5f)
        val layers = params.getInt("layers", 6).coerceIn(1, 20)
        val lw = params.getFloat("lineWidth", 1.4f)
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = lw; color = Color.WHITE
        }
        val cx = width / 2f; val cy = height / 2f
        val maxR = min(width, height) * 0.45f
        for (layer in 1..layers) {
            val scale = layer / layers.toFloat()
            val path = Path()
            val steps = 720
            for (i in 0..steps) {
                val theta = (i / steps.toFloat()) * 2f * PI.toFloat()
                val r = sin(k * theta) * maxR * scale
                val x = cx + cos(theta) * abs(r)
                val y = cy + sin(theta) * abs(r)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            canvas.drawPath(path, paint)
        }
    }
}

/** Domain warping noise field */
class DomainWarpGenerator : ProceduralGenerator {
    override val id = "domain_warp"
    override val name = "Domain Warp"
    override val description = "Domain-warped value noise"
    override val category = "Noise"
    override val version = 1
    override val estimatedCost = 8

    override val parameterSchema = listOf(
        ParameterDef("scale", "Scale", ParameterType.FLOAT, "4", 1f, 12f, 0.25f),
        ParameterDef("warp", "Warp Strength", ParameterType.FLOAT, "0.6", 0f, 1.5f, 0.05f),
        ParameterDef("contrast", "Contrast", ParameterType.FLOAT, "1.2", 0.5f, 2.5f, 0.1f)
    )

    private fun hash2(ix: Int, iy: Int, seed: Long): Float {
        var n = ix * 374761393 + iy * 668265263 + seed.toInt()
        n = (n xor (n ushr 13)) * 1274126177
        return ((n xor (n ushr 16)) and 0xFFFF) / 65535f
    }

    private fun vnoise(x: Float, y: Float, seed: Long): Float {
        val x0 = floor(x).toInt(); val y0 = floor(y).toInt()
        val fx = x - x0; val fy = y - y0
        val ux = fx * fx * (3 - 2 * fx); val uy = fy * fy * (3 - 2 * fy)
        val a = hash2(x0, y0, seed); val b = hash2(x0 + 1, y0, seed)
        val c = hash2(x0, y0 + 1, seed); val d = hash2(x0 + 1, y0 + 1, seed)
        return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy
    }

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val scale = params.getFloat("scale", 4f)
        val warp = params.getFloat("warp", 0.6f)
        val contrast = params.getFloat("contrast", 1.2f)
        val pixels = IntArray(width * height)
        val invW = scale / width; val invH = scale / height
        for (y in 0 until height) {
            for (x in 0 until width) {
                val nx = x * invW; val ny = y * invH
                val wx = nx + warp * vnoise(nx + 0.3f, ny + 1.7f, seed)
                val wy = ny + warp * vnoise(nx + 2.1f, ny + 0.9f, seed + 99)
                var t = vnoise(wx * 2f, wy * 2f, seed + 7)
                t = ((t - 0.5f) * contrast + 0.5f).coerceIn(0f, 1f)
                val c = (t * 255f).toInt()
                pixels[y * width + x] = Color.rgb(c, c, c)
            }
        }
        canvas.drawBitmap(pixels, 0, width, 0f, 0f, width, height, false, null)
    }
}

/** Pendulum / harmonograph multi-sine */
class HarmonographGenerator : ProceduralGenerator {
    override val id = "harmonograph"
    override val name = "Harmonograph"
    override val description = "Multi-frequency damped pendulum curves"
    override val category = "Artistic"
    override val version = 1
    override val estimatedCost = 3

    override val parameterSchema = listOf(
        ParameterDef("f1", "Freq 1", ParameterType.FLOAT, "2.0", 0.5f, 6f, 0.1f),
        ParameterDef("f2", "Freq 2", ParameterType.FLOAT, "3.0", 0.5f, 6f, 0.1f),
        ParameterDef("f3", "Freq 3", ParameterType.FLOAT, "3.0", 0.5f, 6f, 0.1f),
        ParameterDef("f4", "Freq 4", ParameterType.FLOAT, "2.0", 0.5f, 6f, 0.1f),
        ParameterDef("decay", "Decay", ParameterType.FLOAT, "0.0008", 0.0001f, 0.003f, 0.0001f),
        ParameterDef("points", "Points", ParameterType.INT, "4000", 1000f, 12000f, 200f)
    )

    override fun render(canvas: Canvas, width: Int, height: Int, seed: Long, params: ParameterValues, random: SeededRandom) {
        val f1 = params.getFloat("f1", 2f); val f2 = params.getFloat("f2", 3f)
        val f3 = params.getFloat("f3", 3f); val f4 = params.getFloat("f4", 2f)
        val decay = params.getFloat("decay", 0.0008f)
        val n = params.getInt("points", 4000).coerceIn(500, 15000)
        val p1 = ((seed and 0xFFFFL).toFloat() / 65535f) * 6.2832f * PI.toFloat()
        canvas.drawColor(Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.2f; color = Color.WHITE; strokeCap = Paint.Cap.ROUND
        }
        val cx = width / 2f; val cy = height / 2f
        val amp = min(width, height) * 0.42f
        val path = Path()
        for (i in 0 until n) {
            val t = i * 0.02f
            val d = exp(-decay * i)
            val x = cx + amp * d * (sin(f1 * t + p1) + sin(f2 * t) * 0.5f)
            val y = cy + amp * d * (sin(f3 * t) + sin(f4 * t + p1 * 0.7f) * 0.5f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, paint)
    }
}
