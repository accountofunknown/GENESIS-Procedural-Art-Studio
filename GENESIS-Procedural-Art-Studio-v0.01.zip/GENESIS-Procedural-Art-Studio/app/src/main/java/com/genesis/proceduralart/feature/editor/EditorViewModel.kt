package com.genesis.proceduralart.feature.editor

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.core.algorithm.ProceduralGenerator
import com.genesis.proceduralart.core.export.ImageExporter
import com.genesis.proceduralart.core.export.SvgExporter
import com.genesis.proceduralart.core.model.*
import com.genesis.proceduralart.core.random.SeededRandom
import com.genesis.proceduralart.core.render.CpuRenderer
import com.genesis.proceduralart.core.storage.ProjectRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class EditorUiState(
    val generators: List<ProceduralGenerator> = emptyList(),
    val selectedGeneratorId: String? = null,
    val parameters: ParameterValues = ParameterValues(),
    val seed: Long = SeededRandom.randomSeed(),
    val preview: Bitmap? = null,
    val isRendering: Boolean = false,
    val isBusy: Boolean = false,
    val lastError: String? = null,
    val statusMessage: String? = null,
    val renderMs: Long = 0,
    val previewWidth: Int = 512,
    val previewHeight: Int = 512,
    val exportWidth: Int = 1080,
    val exportHeight: Int = 1080,
    val projectId: String? = null,
    val projectName: String = "Untitled"
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val renderer = CpuRenderer()
    private val repo = ProjectRepository(application)
    private val exporter = ImageExporter(application)
    private val svgExporter = SvgExporter(application)
    private var renderJob: Job? = null

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    init {
        GeneratorBootstrap.ensureInitialized()
        val gens = GeneratorRegistry.all()
        val first = gens.firstOrNull()
        _ui.update {
            it.copy(
                generators = gens,
                selectedGeneratorId = first?.id,
                parameters = first?.defaultParameters() ?: ParameterValues()
            )
        }
        requestPreview()
    }

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            val project = repo.getProject(projectId) ?: return@launch
            val layer = project.layers.firstOrNull()
            _ui.update {
                it.copy(
                    projectId = project.id,
                    projectName = project.name,
                    selectedGeneratorId = layer?.generatorId ?: it.selectedGeneratorId,
                    seed = layer?.seed ?: it.seed,
                    parameters = layer?.parameters ?: it.parameters,
                    exportWidth = project.width,
                    exportHeight = project.height
                )
            }
            requestPreview()
        }
    }

    fun selectGenerator(id: String) {
        val gen = GeneratorRegistry.get(id) ?: return
        _ui.update {
            it.copy(
                selectedGeneratorId = id,
                parameters = gen.defaultParameters(),
                seed = SeededRandom.randomSeed()
            )
        }
        requestPreview()
    }

    fun updateParam(key: String, value: String) {
        _ui.update { it.copy(parameters = it.parameters.with(key, value)) }
        requestPreview()
    }

    fun setSeed(seed: Long) {
        _ui.update { it.copy(seed = seed) }
        requestPreview()
    }

    fun setExportSize(size: Int) {
        val s = size.coerceIn(256, 4096)
        _ui.update { it.copy(exportWidth = s, exportHeight = s) }
    }

    fun randomizeSeed() {
        setSeed(SeededRandom.randomSeed())
    }

    fun randomizeParameters() {
        val gen = currentGenerator() ?: return
        val rnd = SeededRandom.create()
        var params = gen.defaultParameters()
        for (def in gen.parameterSchema) {
            when (def.type) {
                ParameterType.FLOAT -> {
                    val min = def.min ?: 0f
                    val max = def.max ?: 1f
                    params = params.with(def.key, (min + rnd.nextFloat() * (max - min)).toString())
                }
                ParameterType.INT -> {
                    val min = (def.min ?: 0f).toInt()
                    val max = (def.max ?: 10f).toInt()
                    params = params.with(def.key, rnd.nextInt(min, max + 1).toString())
                }
                else -> {}
            }
        }
        _ui.update { it.copy(parameters = params, seed = SeededRandom.randomSeed()) }
        requestPreview()
    }

    fun setProjectName(name: String) {
        _ui.update { it.copy(projectName = name) }
    }

    fun saveProject() {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = UUID.randomUUID().toString(),
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val saved = if (state.projectId != null) {
                    val existing = repo.getProject(state.projectId)
                    val project = (existing ?: Project(
                        id = state.projectId,
                        name = state.projectName,
                        createdAt = System.currentTimeMillis(),
                        modifiedAt = System.currentTimeMillis()
                    )).copy(
                        name = state.projectName,
                        width = state.exportWidth,
                        height = state.exportHeight,
                        layers = listOf(layer)
                    )
                    repo.saveProject(project, state.preview)
                } else {
                    repo.createProject(
                        name = state.projectName.ifBlank { "Artwork ${System.currentTimeMillis() % 10000}" },
                        width = state.exportWidth,
                        height = state.exportHeight,
                        layers = listOf(layer),
                        thumbnail = state.preview
                    )
                }
                _ui.update {
                    it.copy(
                        isBusy = false,
                        projectId = saved.id,
                        projectName = saved.name,
                        statusMessage = "Saved: ${saved.name}"
                    )
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "Save failed")
                }
            }
        }
    }

    fun exportPng() {
        exportImage("PNG")
    }

    fun exportJpeg() {
        exportImage("JPEG")
    }

    fun exportSvg() {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = "export",
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val project = Project(
                    id = "export",
                    name = state.projectName,
                    createdAt = System.currentTimeMillis(),
                    modifiedAt = System.currentTimeMillis(),
                    width = state.exportWidth,
                    height = state.exportHeight,
                    layers = listOf(layer)
                )
                val result = renderer.render(
                    RenderRequest(project, state.exportWidth, state.exportHeight)
                )
                if (!result.success || result.bitmap == null) {
                    _ui.update {
                        it.copy(isBusy = false, lastError = result.error ?: "Render for SVG failed")
                    }
                    return@launch
                }
                val baseName = state.projectName
                    .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    .ifBlank { "genesis" }
                val fileName = "${baseName}_${state.seed}"
                val export = svgExporter.saveSvg(
                    result.bitmap,
                    fileName,
                    generatorName = gen.name,
                    seed = state.seed
                )
                result.bitmap.recycle()
                _ui.update {
                    if (export.success) {
                        it.copy(
                            isBusy = false,
                            statusMessage = "SVG exported to ${export.pathHint ?: "Gallery"}"
                        )
                    } else {
                        it.copy(isBusy = false, lastError = export.error ?: "SVG export failed")
                    }
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "SVG export failed")
                }
            }
        }
    }

    private fun exportImage(format: String) {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = "export",
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val project = Project(
                    id = "export",
                    name = state.projectName,
                    createdAt = System.currentTimeMillis(),
                    modifiedAt = System.currentTimeMillis(),
                    width = state.exportWidth,
                    height = state.exportHeight,
                    layers = listOf(layer)
                )
                val result = renderer.render(
                    RenderRequest(project, state.exportWidth, state.exportHeight)
                )
                if (!result.success || result.bitmap == null) {
                    _ui.update {
                        it.copy(isBusy = false, lastError = result.error ?: "Render for export failed")
                    }
                    return@launch
                }
                val baseName = state.projectName
                    .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    .ifBlank { "genesis" }
                val fileName = "${baseName}_${state.seed}"
                val export = exporter.saveToGallery(result.bitmap, fileName, format)
                result.bitmap.recycle()
                _ui.update {
                    if (export.success) {
                        it.copy(
                            isBusy = false,
                            statusMessage = "Exported to ${export.pathHint ?: "Gallery"}"
                        )
                    } else {
                        it.copy(isBusy = false, lastError = export.error ?: "Export failed")
                    }
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "Export failed")
                }
            }
        }
    }

    fun requestPreview() {
        renderJob?.cancel()
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return

        renderJob = viewModelScope.launch {
            _ui.update { it.copy(isRendering = true, lastError = null) }
            val layer = LayerState(
                id = UUID.randomUUID().toString(),
                name = "Main",
                generatorId = genId,
                generatorVersion = gen.version,
                seed = state.seed,
                parameters = state.parameters
            )
            val project = Project(
                id = "preview",
                name = "Preview",
                createdAt = System.currentTimeMillis(),
                modifiedAt = System.currentTimeMillis(),
                width = state.previewWidth,
                height = state.previewHeight,
                layers = listOf(layer)
            )
            val result = renderer.render(
                RenderRequest(project, state.previewWidth, state.previewHeight)
            )
            _ui.update {
                it.copy(
                    isRendering = false,
                    preview = result.bitmap,
                    lastError = result.error,
                    renderMs = result.durationMs
                )
            }
        }
    }

    fun clearStatus() {
        _ui.update { it.copy(statusMessage = null, lastError = null) }
    }

    private fun currentGenerator(): ProceduralGenerator? =
        _ui.value.selectedGeneratorId?.let { GeneratorRegistry.get(it) }

    override fun onCleared() {
        renderJob?.cancel()
        _ui.value.preview?.recycle()
        super.onCleared()
    }
}
