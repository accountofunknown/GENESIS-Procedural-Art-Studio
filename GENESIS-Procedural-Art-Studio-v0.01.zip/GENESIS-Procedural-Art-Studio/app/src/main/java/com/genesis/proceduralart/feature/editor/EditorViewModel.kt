package com.genesis.proceduralart.feature.editor

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.core.algorithm.ProceduralGenerator
import com.genesis.proceduralart.core.model.*
import com.genesis.proceduralart.core.random.SeededRandom
import com.genesis.proceduralart.core.render.CpuRenderer
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class EditorUiState(
    val generators: List<ProceduralGenerator> = emptyList(),
    val selectedGeneratorId: String? = null,
    val parameters: ParameterValues = ParameterValues(),
    val seed: Long = SeededRandom.randomSeed(),
    val preview: Bitmap? = null,
    val isRendering: Boolean = false,
    val lastError: String? = null,
    val renderMs: Long = 0,
    val previewWidth: Int = 512,
    val previewHeight: Int = 512
)

class EditorViewModel : ViewModel() {
    private val renderer = CpuRenderer()
    private var renderJob: Job? = null

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    init {
        GeneratorBootstrap.ensureInitialized()
        val gens = GeneratorRegistry.all()
        val first = gens.firstOrNull()
        _ui.update {
            it.copy(
                generators = gens,
                selectedGeneratorId = first?.id,
                parameters = first?.defaultParameters() ?: ParameterValues()
            )
        }
        requestPreview()
    }

    fun selectGenerator(id: String) {
        val gen = GeneratorRegistry.get(id) ?: return
        _ui.update {
            it.copy(
                selectedGeneratorId = id,
                parameters = gen.defaultParameters(),
                seed = SeededRandom.randomSeed()
            )
        }
        requestPreview()
    }

    fun updateParam(key: String, value: String) {
        _ui.update { it.copy(parameters = it.parameters.with(key, value)) }
        requestPreview()
    }

    fun setSeed(seed: Long) {
        _ui.update { it.copy(seed = seed) }
        requestPreview()
    }

    fun randomizeSeed() {
        setSeed(SeededRandom.randomSeed())
    }

    fun randomizeParameters() {
        val gen = currentGenerator() ?: return
        val rnd = SeededRandom.create()
        var params = gen.defaultParameters()
        for (def in gen.parameterSchema) {
            when (def.type) {
                ParameterType.FLOAT -> {
                    val min = def.min ?: 0f
                    val max = def.max ?: 1f
                    params = params.with(def.key, (min + rnd.nextFloat() * (max - min)).toString())
                }
                ParameterType.INT -> {
                    val min = (def.min ?: 0f).toInt()
                    val max = (def.max ?: 10f).toInt()
                    params = params.with(def.key, rnd.nextInt(min, max + 1).toString())
                }
                else -> {}
            }
        }
        _ui.update { it.copy(parameters = params, seed = SeededRandom.randomSeed()) }
        requestPreview()
    }

    fun requestPreview() {
        renderJob?.cancel()
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return

        renderJob = viewModelScope.launch {
            _ui.update { it.copy(isRendering = true, lastError = null) }
            val layer = LayerState(
                id = UUID.randomUUID().toString(),
                name = "Main",
                generatorId = genId,
                generatorVersion = gen.version,
                seed = state.seed,
                parameters = state.parameters
            )
            val project = Project(
                id = "preview",
                name = "Preview",
                createdAt = System.currentTimeMillis(),
                modifiedAt = System.currentTimeMillis(),
                width = state.previewWidth,
                height = state.previewHeight,
                layers = listOf(layer)
            )
            val result = renderer.render(
                RenderRequest(project, state.previewWidth, state.previewHeight)
            )
            _ui.update {
                it.copy(
                    isRendering = false,
                    preview = result.bitmap,
                    lastError = result.error,
                    renderMs = result.durationMs
                )
            }
        }
    }

    private fun currentGenerator(): ProceduralGenerator? =
        _ui.value.selectedGeneratorId?.let { GeneratorRegistry.get(it) }

    override fun onCleared() {
        renderJob?.cancel()
        _ui.value.preview?.recycle()
        super.onCleared()
    }
}
