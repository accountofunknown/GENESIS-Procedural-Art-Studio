package com.genesis.proceduralart.feature.editor

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.core.algorithm.ProceduralGenerator
import com.genesis.proceduralart.core.export.ImageExporter
import com.genesis.proceduralart.core.export.SvgExporter
import com.genesis.proceduralart.core.color.Colorize
import com.genesis.proceduralart.core.model.*
import com.genesis.proceduralart.core.random.SeededRandom
import com.genesis.proceduralart.core.render.CpuRenderer
import com.genesis.proceduralart.core.storage.ProjectRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class EditorUiState(
    val generators: List<ProceduralGenerator> = emptyList(),
    val selectedGeneratorId: String? = null,
    val parameters: ParameterValues = ParameterValues(),
    val seed: Long = SeededRandom.randomSeed(),
    val preview: Bitmap? = null,
    val isRendering: Boolean = false,
    val isBusy: Boolean = false,
    val lastError: String? = null,
    val statusMessage: String? = null,
    val renderMs: Long = 0,
    val previewWidth: Int = 512,
    val previewHeight: Int = 512,
    val exportWidth: Int = 1080,
    val exportHeight: Int = 1080,
    val projectId: String? = null,
    val projectName: String = "Untitled",
    val colorMode: Int = 0,
    val hueShift: Float = 0f,
    val colorSaturation: Float = 1f,
    val colorBrightness: Float = 1f,
    val customColors: List<Int> = com.genesis.proceduralart.core.color.Colorize.defaultCustomColors,
    val selectedColorSlot: Int = 0,
    val isLive: Boolean = false
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val renderer = CpuRenderer()
    private val repo = ProjectRepository(application)
    private val exporter = ImageExporter(application)
    private val svgExporter = SvgExporter(application)
    private var renderJob: Job? = null
    private var liveJob: Job? = null

    private val _ui = MutableStateFlow(EditorUiState())
    val ui: StateFlow<EditorUiState> = _ui.asStateFlow()

    init {
        GeneratorBootstrap.ensureInitialized()
        val gens = GeneratorRegistry.all()
        val first = gens.firstOrNull()
        _ui.update {
            it.copy(
                generators = gens,
                selectedGeneratorId = first?.id,
                parameters = first?.defaultParameters() ?: ParameterValues()
            )
        }
        requestPreview()
    }

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            val project = repo.getProject(projectId) ?: return@launch
            val layer = project.layers.firstOrNull()
            _ui.update {
                it.copy(
                    projectId = project.id,
                    projectName = project.name,
                    selectedGeneratorId = layer?.generatorId ?: it.selectedGeneratorId,
                    seed = layer?.seed ?: it.seed,
                    parameters = layer?.parameters ?: it.parameters,
                    exportWidth = project.width,
                    exportHeight = project.height
                )
            }
            requestPreview()
        }
    }

    fun selectGenerator(id: String) {
        val gen = GeneratorRegistry.get(id) ?: return
        _ui.update {
            it.copy(
                selectedGeneratorId = id,
                parameters = gen.defaultParameters(),
                seed = SeededRandom.randomSeed()
            )
        }
        requestPreview()
    }

    fun updateParam(key: String, value: String) {
        _ui.update { it.copy(parameters = it.parameters.with(key, value)) }
        requestPreview()
    }

    fun setSeed(seed: Long) {
        _ui.update { it.copy(seed = seed) }
        requestPreview()
    }

    fun setExportSize(size: Int) {
        val s = size.coerceIn(256, 4096)
        _ui.update { it.copy(exportWidth = s, exportHeight = s) }
    }

    fun setColorMode(mode: Int) {
        _ui.update { it.copy(colorMode = mode.coerceIn(0, Colorize.modeNames.lastIndex)) }
        requestPreview()
    }

    fun setHueShift(h: Float) {
        _ui.update { it.copy(hueShift = h) }
        requestPreview()
    }

    fun setColorSaturation(s: Float) {
        _ui.update { it.copy(colorSaturation = s) }
        requestPreview()
    }

    fun setColorBrightness(b: Float) {
        _ui.update { it.copy(colorBrightness = b) }
        requestPreview()
    }

    fun selectColorSlot(index: Int) {
        _ui.update { it.copy(selectedColorSlot = index.coerceIn(0, it.customColors.lastIndex.coerceAtLeast(0))) }
    }

    fun setCustomColorAt(index: Int, color: Int) {
        _ui.update { st ->
            val list = st.customColors.toMutableList()
            if (list.isEmpty()) {
                list.addAll(Colorize.defaultCustomColors)
            }
            val i = index.coerceIn(0, list.lastIndex)
            list[i] = color
            st.copy(customColors = list, colorMode = Colorize.MODE_CUSTOM, selectedColorSlot = i)
        }
        requestPreview()
    }

    fun setCustomColorHsv(hue: Float, sat: Float, value: Float) {
        val c = android.graphics.Color.HSVToColor(floatArrayOf(hue, sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f)))
        val idx = _ui.value.selectedColorSlot
        setCustomColorAt(idx, c)
    }

    fun applyPresetPalette(index: Int) {
        val preset = Colorize.presetPalettes.getOrNull(index) ?: return
        _ui.update {
            it.copy(
                customColors = preset.second,
                colorMode = Colorize.MODE_CUSTOM,
                selectedColorSlot = 0
            )
        }
        requestPreview()
    }

    fun addCustomColorSlot() {
        _ui.update { st ->
            if (st.customColors.size >= 6) return@update st
            val list = st.customColors.toMutableList()
            list.add(android.graphics.Color.WHITE)
            st.copy(customColors = list, colorMode = Colorize.MODE_CUSTOM, selectedColorSlot = list.lastIndex)
        }
        requestPreview()
    }

    fun removeCustomColorSlot() {
        _ui.update { st ->
            if (st.customColors.size <= 2) return@update st
            val list = st.customColors.toMutableList()
            val idx = st.selectedColorSlot.coerceIn(0, list.lastIndex)
            list.removeAt(idx)
            st.copy(
                customColors = list,
                selectedColorSlot = idx.coerceAtMost(list.lastIndex),
                colorMode = Colorize.MODE_CUSTOM
            )
        }
        requestPreview()
    }

    private fun colorizeIfNeeded(bitmap: Bitmap): Bitmap {
        val st = _ui.value
        if (st.colorMode <= 0) return bitmap
        return Colorize.apply(
            bitmap,
            st.colorMode,
            st.hueShift,
            st.colorSaturation,
            st.colorBrightness,
            st.customColors
        )
    }

    fun randomizeSeed() {
        setSeed(SeededRandom.randomSeed())
    }

    fun randomizeParameters() {
        val gen = currentGenerator() ?: return
        val rnd = SeededRandom.create()
        var params = gen.defaultParameters()
        for (def in gen.parameterSchema) {
            when (def.type) {
                ParameterType.FLOAT -> {
                    val min = def.min ?: 0f
                    val max = def.max ?: 1f
                    params = params.with(def.key, (min + rnd.nextFloat() * (max - min)).toString())
                }
                ParameterType.INT -> {
                    val min = (def.min ?: 0f).toInt()
                    val max = (def.max ?: 10f).toInt()
                    params = params.with(def.key, rnd.nextInt(min, max + 1).toString())
                }
                else -> {}
            }
        }
        _ui.update { it.copy(parameters = params, seed = SeededRandom.randomSeed()) }
        requestPreview()
    }

    fun setProjectName(name: String) {
        _ui.update { it.copy(projectName = name) }
    }

    fun saveProject() {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = UUID.randomUUID().toString(),
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val saved = if (state.projectId != null) {
                    val existing = repo.getProject(state.projectId)
                    val project = (existing ?: Project(
                        id = state.projectId,
                        name = state.projectName,
                        createdAt = System.currentTimeMillis(),
                        modifiedAt = System.currentTimeMillis()
                    )).copy(
                        name = state.projectName,
                        width = state.exportWidth,
                        height = state.exportHeight,
                        layers = listOf(layer)
                    )
                    repo.saveProject(project, state.preview)
                } else {
                    repo.createProject(
                        name = state.projectName.ifBlank { "Artwork ${System.currentTimeMillis() % 10000}" },
                        width = state.exportWidth,
                        height = state.exportHeight,
                        layers = listOf(layer),
                        thumbnail = state.preview
                    )
                }
                _ui.update {
                    it.copy(
                        isBusy = false,
                        projectId = saved.id,
                        projectName = saved.name,
                        statusMessage = "Saved: ${saved.name}"
                    )
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "Save failed")
                }
            }
        }
    }

    fun exportPng() {
        exportImage("PNG")
    }

    fun exportJpeg() {
        exportImage("JPEG")
    }

    fun exportSvg() {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = "export",
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val project = Project(
                    id = "export",
                    name = state.projectName,
                    createdAt = System.currentTimeMillis(),
                    modifiedAt = System.currentTimeMillis(),
                    width = state.exportWidth,
                    height = state.exportHeight,
                    layers = listOf(layer)
                )
                val result = renderer.render(
                    RenderRequest(project, state.exportWidth, state.exportHeight)
                )
                if (!result.success || result.bitmap == null) {
                    _ui.update {
                        it.copy(isBusy = false, lastError = result.error ?: "Render for SVG failed")
                    }
                    return@launch
                }
                val baseName = state.projectName
                    .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    .ifBlank { "genesis" }
                val fileName = "${baseName}_${state.seed}"
                val coloredSvg = colorizeIfNeeded(result.bitmap)
                val export = svgExporter.saveSvg(
                    coloredSvg,
                    fileName,
                    generatorName = gen.name,
                    seed = state.seed
                )
                if (coloredSvg !== result.bitmap) coloredSvg.recycle()
                result.bitmap.recycle()
                _ui.update {
                    if (export.success) {
                        it.copy(
                            isBusy = false,
                            statusMessage = "SVG exported to ${export.pathHint ?: "Gallery"}"
                        )
                    } else {
                        it.copy(isBusy = false, lastError = export.error ?: "SVG export failed")
                    }
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "SVG export failed")
                }
            }
        }
    }

    private fun exportImage(format: String) {
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return
        viewModelScope.launch {
            _ui.update { it.copy(isBusy = true, statusMessage = null, lastError = null) }
            try {
                val layer = LayerState(
                    id = "export",
                    name = "Main",
                    generatorId = genId,
                    generatorVersion = gen.version,
                    seed = state.seed,
                    parameters = state.parameters
                )
                val project = Project(
                    id = "export",
                    name = state.projectName,
                    createdAt = System.currentTimeMillis(),
                    modifiedAt = System.currentTimeMillis(),
                    width = state.exportWidth,
                    height = state.exportHeight,
                    layers = listOf(layer)
                )
                val result = renderer.render(
                    RenderRequest(project, state.exportWidth, state.exportHeight)
                )
                if (!result.success || result.bitmap == null) {
                    _ui.update {
                        it.copy(isBusy = false, lastError = result.error ?: "Render for export failed")
                    }
                    return@launch
                }
                val baseName = state.projectName
                    .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                    .ifBlank { "genesis" }
                val fileName = "${baseName}_${state.seed}"
                val colored = colorizeIfNeeded(result.bitmap)
                val export = exporter.saveToGallery(colored, fileName, format)
                if (colored !== result.bitmap) colored.recycle()
                result.bitmap.recycle()
                _ui.update {
                    if (export.success) {
                        it.copy(
                            isBusy = false,
                            statusMessage = "Exported to ${export.pathHint ?: "Gallery"}"
                        )
                    } else {
                        it.copy(isBusy = false, lastError = export.error ?: "Export failed")
                    }
                }
            } catch (e: Exception) {
                _ui.update {
                    it.copy(isBusy = false, lastError = e.message ?: "Export failed")
                }
            }
        }
    }

    fun toggleLive() {
        val next = !_ui.value.isLive
        _ui.update { it.copy(isLive = next) }
        if (next) startLive() else stopLive()
    }

    fun stopLive() {
        liveJob?.cancel()
        liveJob = null
        if (_ui.value.isLive) _ui.update { it.copy(isLive = false) }
    }

        private fun startLive() {
        liveJob?.cancel()
        liveJob = viewModelScope.launch {
            val prevW = _ui.value.previewWidth
            val prevH = _ui.value.previewHeight
            // Smaller preview while live for smoother FPS
            _ui.update { it.copy(previewWidth = 320, previewHeight = 320) }
            // Snapshot base parameters so we oscillate around the user's settings
            val baseParams = _ui.value.parameters
            val baseSeed = _ui.value.seed
            try {
                var tick = 0
                while (isActive && _ui.value.isLive) {
                    tick++
                    val st = _ui.value
                    val gen = st.generators.find { it.id == st.selectedGeneratorId }
                    var params = baseParams
                    if (gen != null) {
                        for (def in gen.parameterSchema) {
                            when (def.type) {
                                com.genesis.proceduralart.core.model.ParameterType.FLOAT,
                                com.genesis.proceduralart.core.model.ParameterType.INT -> {
                                    val min = def.min ?: continue
                                    val max = def.max ?: continue
                                    if (max <= min) continue
                                    val base = baseParams.values[def.key]?.toFloatOrNull()
                                        ?: def.defaultValue.toFloatOrNull()
                                        ?: ((min + max) * 0.5f)
                                    val span = (max - min)
                                    // Different params get different phase/speed so motion feels organic
                                    val speed = 0.11f + (def.key.hashCode().and(7)) * 0.03f
                                    val phase = (def.key.hashCode().and(15)) * 0.4f
                                    val wave = kotlin.math.sin(tick * speed + phase)
                                    // Keep motion within ~35% of range around base (clamped to min/max)
                                    val amplitude = span * 0.35f
                                    val next = (base + wave * amplitude).coerceIn(min, max)
                                    val value = if (def.type == com.genesis.proceduralart.core.model.ParameterType.INT)
                                        next.toInt().toString()
                                    else
                                        next.toString()
                                    params = params.with(def.key, value)
                                }
                                else -> { /* skip bool/color/choice */ }
                            }
                        }
                        // Explicit strong phase for time/phase keys if present
                        for (key in listOf("time", "phase", "rotation", "offset")) {
                            val def = gen.parameterSchema.find { it.key == key } ?: continue
                            val min = def.min ?: 0f
                            val max = def.max ?: 6.28f
                            val driven = min + ((tick * 0.2f) % 1f) * (max - min)
                            params = params.with(key, driven.toString())
                        }
                    }
                    // Always advance seed so RNG-based generators (stipple, voronoi sites, particles…) re-roll
                    val newSeed = baseSeed + tick * 97_531_337L
                    _ui.update {
                        it.copy(seed = newSeed, parameters = params)
                    }
                    requestPreview()
                    delay(85)
                }
            } finally {
                // Restore base params & resolution when stopping
                _ui.update {
                    it.copy(
                        previewWidth = prevW,
                        previewHeight = prevH,
                        parameters = baseParams,
                        seed = baseSeed
                    )
                }
                requestPreview()
            }
        }
    }


    fun requestPreview() {

        renderJob?.cancel()
        val state = _ui.value
        val genId = state.selectedGeneratorId ?: return
        val gen = GeneratorRegistry.get(genId) ?: return

        renderJob = viewModelScope.launch {
            _ui.update { it.copy(isRendering = true, lastError = null) }
            val layer = LayerState(
                id = UUID.randomUUID().toString(),
                name = "Main",
                generatorId = genId,
                generatorVersion = gen.version,
                seed = state.seed,
                parameters = state.parameters
            )
            val project = Project(
                id = "preview",
                name = "Preview",
                createdAt = System.currentTimeMillis(),
                modifiedAt = System.currentTimeMillis(),
                width = state.previewWidth,
                height = state.previewHeight,
                layers = listOf(layer)
            )
            val result = renderer.render(
                RenderRequest(project, state.previewWidth, state.previewHeight)
            )
            _ui.update {
                it.copy(
                    isRendering = false,
                    preview = colorizeIfNeeded(result.bitmap!!),
                    lastError = result.error,
                    renderMs = result.durationMs
                )
            }
        }
    }

    fun clearStatus() {
        _ui.update { it.copy(statusMessage = null, lastError = null) }
    }

    private fun currentGenerator(): ProceduralGenerator? =
        _ui.value.selectedGeneratorId?.let { GeneratorRegistry.get(it) }

    override fun onCleared() {
        renderJob?.cancel()
        _ui.value.preview?.recycle()
        super.onCleared()
    }
}
