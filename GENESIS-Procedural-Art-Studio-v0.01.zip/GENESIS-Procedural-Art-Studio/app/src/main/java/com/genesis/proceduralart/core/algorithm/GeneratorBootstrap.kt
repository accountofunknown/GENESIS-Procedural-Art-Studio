package com.genesis.proceduralart.core.algorithm

object GeneratorBootstrap {
    private var initialized = false

    fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            // Geometric
            GeneratorRegistry.register(ConcentricCirclesGenerator())
            GeneratorRegistry.register(RadialMandalaGenerator())
            GeneratorRegistry.register(GridLinesGenerator())
            GeneratorRegistry.register(RecursiveSubdivisionGenerator())
            GeneratorRegistry.register(VoronoiGenerator())
            GeneratorRegistry.register(PhyllotaxisGenerator())
            GeneratorRegistry.register(TruchetGenerator())
            // Fractal
            GeneratorRegistry.register(MandelbrotGenerator())
            GeneratorRegistry.register(JuliaGenerator())
            GeneratorRegistry.register(SierpinskiGenerator())
            GeneratorRegistry.register(RecursiveTreeGenerator())
            GeneratorRegistry.register(LSystemGenerator())
            // Noise / organic
            GeneratorRegistry.register(ValueNoiseGenerator())
            GeneratorRegistry.register(WaveInterferenceGenerator())
            GeneratorRegistry.register(FlowFieldGenerator())
            GeneratorRegistry.register(ContourGenerator())
            // Artistic
            GeneratorRegistry.register(StippleGenerator())
            GeneratorRegistry.register(LissajousGenerator())
            GeneratorRegistry.register(HalftoneGenerator())
            GeneratorRegistry.register(SpiralGalaxyGenerator())
            GeneratorRegistry.register(PlasmaGenerator())
            initialized = true
        }
    }
}
