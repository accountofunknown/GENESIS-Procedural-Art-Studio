package com.genesis.proceduralart.core.algorithm

object GeneratorBootstrap {
    private var initialized = false

    fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            GeneratorRegistry.register(ConcentricCirclesGenerator())
            GeneratorRegistry.register(RadialMandalaGenerator())
            GeneratorRegistry.register(GridLinesGenerator())
            GeneratorRegistry.register(RecursiveSubdivisionGenerator())
            GeneratorRegistry.register(MandelbrotGenerator())
            GeneratorRegistry.register(JuliaGenerator())
            GeneratorRegistry.register(SierpinskiGenerator())
            GeneratorRegistry.register(RecursiveTreeGenerator())
            GeneratorRegistry.register(ValueNoiseGenerator())
            GeneratorRegistry.register(WaveInterferenceGenerator())
            GeneratorRegistry.register(StippleGenerator())
            initialized = true
        }
    }
}
