package com.genesis.proceduralart.core.algorithm

object GeneratorBootstrap {
    private var initialized = false

    fun ensureInitialized() {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            // Geometric
            GeneratorRegistry.register(ConcentricCirclesGenerator())
            GeneratorRegistry.register(RadialMandalaGenerator())
            GeneratorRegistry.register(GridLinesGenerator())
            GeneratorRegistry.register(RecursiveSubdivisionGenerator())
            GeneratorRegistry.register(VoronoiGenerator())
            GeneratorRegistry.register(PhyllotaxisGenerator())
            GeneratorRegistry.register(TruchetGenerator())
            GeneratorRegistry.register(CirclePackingGenerator())
            GeneratorRegistry.register(ZonePlateGenerator())
            GeneratorRegistry.register(SpiralWeaveGenerator())
            GeneratorRegistry.register(HexGridGenerator())
            GeneratorRegistry.register(PolarRoseGenerator())
            // Fractal
            GeneratorRegistry.register(MandelbrotGenerator())
            GeneratorRegistry.register(JuliaGenerator())
            GeneratorRegistry.register(SierpinskiGenerator())
            GeneratorRegistry.register(RecursiveTreeGenerator())
            GeneratorRegistry.register(LSystemGenerator())
            GeneratorRegistry.register(CliffordAttractorGenerator())
            GeneratorRegistry.register(DeJongAttractorGenerator())
            GeneratorRegistry.register(CellularAutomatonGenerator())
            GeneratorRegistry.register(HopalongAttractorGenerator())
            GeneratorRegistry.register(LogisticMapGenerator())
            // Noise / organic
            GeneratorRegistry.register(ValueNoiseGenerator())
            GeneratorRegistry.register(WaveInterferenceGenerator())
            GeneratorRegistry.register(FlowFieldGenerator())
            GeneratorRegistry.register(ContourGenerator())
            GeneratorRegistry.register(ReactionDiffusionGenerator())
            GeneratorRegistry.register(RidgedTerrainGenerator())
            GeneratorRegistry.register(DomainWarpGenerator())
            // Artistic
            GeneratorRegistry.register(StippleGenerator())
            GeneratorRegistry.register(LissajousGenerator())
            GeneratorRegistry.register(HalftoneGenerator())
            GeneratorRegistry.register(SpiralGalaxyGenerator())
            GeneratorRegistry.register(PlasmaGenerator())
            GeneratorRegistry.register(ParticleFieldGenerator())
            GeneratorRegistry.register(KaleidoscopeGenerator())
            GeneratorRegistry.register(InkBlotGenerator())
            GeneratorRegistry.register(HarmonographGenerator())
            // Advanced set
            GeneratorRegistry.register(LorenzAttractorGenerator())
            GeneratorRegistry.register(RosslerAttractorGenerator())
            GeneratorRegistry.register(SuperformulaGenerator())
            GeneratorRegistry.register(LyapunovFractalGenerator())
            GeneratorRegistry.register(DlaGenerator())
            GeneratorRegistry.register(EpicycloidGenerator())
            GeneratorRegistry.register(QuasicrystalGenerator())
            GeneratorRegistry.register(DoublePendulumGenerator())
            GeneratorRegistry.register(ApollonianGenerator())
            GeneratorRegistry.register(IrisFieldGenerator())
            initialized = true
        }
    }
}
