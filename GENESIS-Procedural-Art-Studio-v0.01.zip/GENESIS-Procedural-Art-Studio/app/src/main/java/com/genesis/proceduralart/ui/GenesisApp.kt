package com.genesis.proceduralart.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.genesis.proceduralart.feature.editor.EditorScreen
import com.genesis.proceduralart.feature.explore.ExploreScreen
import com.genesis.proceduralart.feature.gallery.GalleryScreen
import com.genesis.proceduralart.feature.home.HomeScreen
import com.genesis.proceduralart.feature.settings.SettingsScreen
import com.genesis.proceduralart.ui.theme.MidGray
import com.genesis.proceduralart.ui.theme.PureBlack
import com.genesis.proceduralart.ui.theme.PureWhite
import com.genesis.proceduralart.ui.theme.SoftGray

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    data object Home : Screen("home", "Home", Icons.Default.Home)
    data object Explore : Screen("explore", "Explore", Icons.Default.Explore)
    data object Create : Screen("create", "Create", Icons.Default.Create)
    data object Gallery : Screen("gallery", "Gallery", Icons.Default.PhotoLibrary)
    data object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

private val bottomScreens = listOf(
    Screen.Home,
    Screen.Explore,
    Screen.Create,
    Screen.Gallery,
    Screen.Settings
)

private fun isCreateRoute(route: String?): Boolean =
    route == "create" || route?.startsWith("create/") == true

private fun tabSelected(currentRoute: String?, screen: Screen): Boolean {
    return when (screen) {
        Screen.Create -> isCreateRoute(currentRoute)
        else -> currentRoute == screen.route
    }
}

@Composable
fun GenesisApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        containerColor = PureBlack,
        bottomBar = {
            NavigationBar(
                containerColor = PureBlack,
                contentColor = PureWhite
            ) {
                bottomScreens.forEach { screen ->
                    val selected = tabSelected(currentRoute, screen)
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        selected = selected,
                        onClick = {
                            // Always jump to the tab root; avoid stacking create/{id}
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                // Don't restore Create state — prevents ghost/black flashes
                                restoreState = screen.route != Screen.Create.route
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            selectedTextColor = PureWhite,
                            unselectedIconColor = SoftGray,
                            unselectedTextColor = SoftGray,
                            indicatorColor = MidGray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        // Opaque root so previous destinations never show through
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PureBlack)
        ) {
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier
                    .fillMaxSize()
                    .background(PureBlack)
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        onCreate = {
                            navController.navigate(Screen.Create.route) {
                                launchSingleTop = true
                            }
                        },
                        onExplore = {
                            navController.navigate(Screen.Explore.route) {
                                launchSingleTop = true
                            }
                        },
                        onGallery = {
                            navController.navigate(Screen.Gallery.route) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(Screen.Explore.route) {
                    ExploreScreen(
                        onOpenGenerator = { generatorId ->
                            navController.navigate("create?generatorId=$generatorId") {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(
                    route = "create?generatorId={generatorId}",
                    arguments = listOf(
                        navArgument("generatorId") {
                            type = NavType.StringType
                            nullable = true
                            defaultValue = null
                        }
                    )
                ) { entry ->
                    val generatorId = entry.arguments?.getString("generatorId")
                    EditorScreen(initialGeneratorId = generatorId)
                }
                composable(Screen.Create.route) {
                    EditorScreen()
                }
                composable(
                    route = "create/{projectId}",
                    arguments = listOf(navArgument("projectId") { type = NavType.StringType })
                ) { entry ->
                    val id = entry.arguments?.getString("projectId")
                    EditorScreen(projectIdToLoad = id)
                }
                composable(Screen.Gallery.route) {
                    GalleryScreen(
                        onOpenProject = { id ->
                            navController.navigate("create/$id") {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(Screen.Settings.route) {
                    SettingsScreen()
                }
            }
        }
    }
}
