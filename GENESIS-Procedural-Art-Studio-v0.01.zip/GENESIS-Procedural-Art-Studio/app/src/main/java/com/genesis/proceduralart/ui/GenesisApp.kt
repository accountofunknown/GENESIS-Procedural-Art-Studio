package com.genesis.proceduralart.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.genesis.proceduralart.feature.editor.EditorScreen
import com.genesis.proceduralart.feature.explore.ExploreScreen
import com.genesis.proceduralart.feature.gallery.GalleryScreen
import com.genesis.proceduralart.feature.home.HomeScreen
import com.genesis.proceduralart.feature.settings.SettingsScreen
import com.genesis.proceduralart.ui.theme.MidGray
import com.genesis.proceduralart.ui.theme.PureBlack
import com.genesis.proceduralart.ui.theme.PureWhite
import com.genesis.proceduralart.ui.theme.SoftGray

enum class Tab {
    Home, Explore, Create, Gallery, Settings
}

private data class TabItem(
    val tab: Tab,
    val label: String,
    val icon: ImageVector
)

private val tabs = listOf(
    TabItem(Tab.Home, "Home", Icons.Default.Home),
    TabItem(Tab.Explore, "Explore", Icons.Default.Explore),
    TabItem(Tab.Create, "Create", Icons.Default.Create),
    TabItem(Tab.Gallery, "Gallery", Icons.Default.PhotoLibrary),
    TabItem(Tab.Settings, "Settings", Icons.Default.Settings)
)

@Composable
fun GenesisApp() {
    var selectedTab by rememberSaveable { mutableStateOf(Tab.Home) }
    // Optional args for Create when opened from Explore / Gallery
    var createGeneratorId by remember { mutableStateOf<String?>(null) }
    var createProjectId by remember { mutableStateOf<String?>(null) }

    fun openCreate(generatorId: String? = null, projectId: String? = null) {
        createGeneratorId = generatorId
        createProjectId = projectId
        selectedTab = Tab.Create
    }

    Scaffold(
        containerColor = PureBlack,
        bottomBar = {
            NavigationBar(
                containerColor = PureBlack,
                contentColor = PureWhite
            ) {
                tabs.forEach { item ->
                    val selected = selectedTab == item.tab
                    NavigationBarItem(
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        selected = selected,
                        onClick = {
                            if (item.tab == Tab.Create) {
                                // Fresh create when user taps Create tab
                                createGeneratorId = null
                                createProjectId = null
                            }
                            selectedTab = item.tab
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureWhite,
                            selectedTextColor = PureWhite,
                            unselectedIconColor = SoftGray,
                            unselectedTextColor = SoftGray,
                            indicatorColor = MidGray
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PureBlack)
        ) {
            // Only one screen composition — no NavHost transitions / ghosting
            when (selectedTab) {
                Tab.Home -> {
                    HomeScreen(
                        onCreate = { openCreate() },
                        onExplore = { selectedTab = Tab.Explore },
                        onGallery = { selectedTab = Tab.Gallery }
                    )
                }
                Tab.Explore -> {
                    ExploreScreen(
                        onOpenGenerator = { id -> openCreate(generatorId = id) }
                    )
                }
                Tab.Create -> {
                    // Key forces a clean Editor instance when args change
                    val key = "${createGeneratorId.orEmpty()}|${createProjectId.orEmpty()}"
                    androidx.compose.runtime.key(key) {
                        EditorScreen(
                            initialGeneratorId = createGeneratorId,
                            projectIdToLoad = createProjectId
                        )
                    }
                }
                Tab.Gallery -> {
                    GalleryScreen(
                        onOpenProject = { id -> openCreate(projectId = id) }
                    )
                }
                Tab.Settings -> {
                    SettingsScreen()
                }
            }
        }
    }
}
