package com.genesis.proceduralart.core.storage

import android.content.Context
import android.graphics.Bitmap
import com.genesis.proceduralart.core.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Simple file-based project store.
 * Each project = JSON manifest + optional PNG thumbnail under app-private files/projects/.
 */
class ProjectRepository(private val context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        prettyPrint = true
        encodeDefaults = true
    }

    private val rootDir: File
        get() = File(context.filesDir, "projects").also { it.mkdirs() }

    suspend fun listProjects(): List<Project> = withContext(Dispatchers.IO) {
        rootDir.listFiles()
            ?.filter { it.isDirectory }
            ?.mapNotNull { dir ->
                val manifest = File(dir, "project.json")
                if (!manifest.exists()) return@mapNotNull null
                runCatching {
                    json.decodeFromString<Project>(manifest.readText())
                }.getOrNull()
            }
            ?.sortedByDescending { it.modifiedAt }
            ?: emptyList()
    }

    suspend fun getProject(id: String): Project? = withContext(Dispatchers.IO) {
        val manifest = File(projectDir(id), "project.json")
        if (!manifest.exists()) return@withContext null
        runCatching { json.decodeFromString<Project>(manifest.readText()) }.getOrNull()
    }

    suspend fun saveProject(project: Project, thumbnail: Bitmap? = null): Project =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val toSave = project.copy(
                modifiedAt = now,
                createdAt = if (project.createdAt == 0L) now else project.createdAt
            )
            val dir = projectDir(toSave.id)
            dir.mkdirs()
            File(dir, "project.json").writeText(json.encodeToString(toSave))
            if (thumbnail != null && !thumbnail.isRecycled) {
                val thumbFile = File(dir, "thumb.png")
                FileOutputStream(thumbFile).use { out ->
                    thumbnail.compress(Bitmap.CompressFormat.PNG, 90, out)
                }
            }
            toSave
        }

    suspend fun createProject(
        name: String,
        width: Int,
        height: Int,
        layers: List<com.genesis.proceduralart.core.model.LayerState>,
        backgroundColor: Long = 0xFF000000,
        thumbnail: Bitmap? = null
    ): Project {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val project = Project(
            id = id,
            name = name,
            createdAt = now,
            modifiedAt = now,
            width = width,
            height = height,
            backgroundColor = backgroundColor,
            layers = layers
        )
        return saveProject(project, thumbnail)
    }

    suspend fun deleteProject(id: String): Boolean = withContext(Dispatchers.IO) {
        val dir = projectDir(id)
        if (!dir.exists()) return@withContext false
        dir.deleteRecursively()
    }

    suspend fun renameProject(id: String, newName: String): Project? = withContext(Dispatchers.IO) {
        val existing = getProject(id) ?: return@withContext null
        saveProject(existing.copy(name = newName.trim().ifEmpty { existing.name }))
    }

    fun thumbnailFile(id: String): File = File(projectDir(id), "thumb.png")

    private fun projectDir(id: String): File = File(rootDir, id)
}
