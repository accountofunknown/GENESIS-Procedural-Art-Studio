package com.genesis.proceduralart.core.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.core.model.LayerState
import com.genesis.proceduralart.core.model.Project
import com.genesis.proceduralart.core.model.RenderRequest
import com.genesis.proceduralart.core.model.RenderResult
import com.genesis.proceduralart.core.model.RendererType
import com.genesis.proceduralart.core.random.SeededRandom
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

class CpuRenderer {

    suspend fun render(request: RenderRequest): RenderResult = withContext(Dispatchers.Default) {
        GeneratorBootstrap.ensureInitialized()
        val start = System.currentTimeMillis()
        try {
            val w = request.width.coerceIn(64, 4096)
            val h = request.height.coerceIn(64, 4096)
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)

            // Background
            canvas.drawColor(request.project.backgroundColor.toInt())

            if (request.project.layers.isEmpty()) {
                // Fallback: render a default generator if no layers
                val gen = GeneratorRegistry.all().firstOrNull()
                if (gen != null) {
                    val seed = SeededRandom.randomSeed()
                    val random = SeededRandom(seed)
                    gen.render(canvas, w, h, seed, gen.defaultParameters(), random)
                }
            } else {
                for (layer in request.project.layers) {
                    coroutineContext.ensureActive()
                    if (!layer.visible || layer.opacity <= 0.01f) continue
                    renderLayer(canvas, w, h, layer)
                }
            }

            val duration = System.currentTimeMillis() - start
            RenderResult(
                success = true,
                bitmap = bitmap,
                usedRenderer = RendererType.CPU,
                durationMs = duration
            )
        } catch (e: OutOfMemoryError) {
            RenderResult(success = false, error = "Out of memory. Try a smaller resolution.")
        } catch (e: Exception) {
            RenderResult(success = false, error = e.message ?: "Render failed")
        }
    }

    private fun renderLayer(canvas: Canvas, w: Int, h: Int, layer: LayerState) {
        val gen = GeneratorRegistry.get(layer.generatorId) ?: return
        val random = SeededRandom(layer.seed)
        // Simple opacity via layer paint (full alpha for v0.01; advanced blend modes deferred)
        val save = canvas.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), (layer.opacity * 255).toInt())
        try {
            gen.render(canvas, w, h, layer.seed, layer.parameters, random)
        } finally {
            canvas.restoreToCount(save)
        }
    }
}
