package com.genesis.proceduralart.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.ui.theme.*

@Composable
fun HomeScreen(
    onCreate: () -> Unit,
    onExplore: () -> Unit,
    onGallery: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "GENESIS",
            style = MaterialTheme.typography.displayLarge,
            color = PureWhite
        )
        Text(
            text = "Procedural Art Studio  ·  v0.01",
            style = MaterialTheme.typography.bodyMedium,
            color = SoftGray
        )
        Spacer(Modifier.height(28.dp))

        PrimaryActionCard(
            title = "New Artwork",
            subtitle = "Start a blank procedural canvas",
            onClick = onCreate
        )
        Spacer(Modifier.height(12.dp))
        SecondaryActionCard(
            title = "Explore Generators",
            subtitle = "Browse algorithms and presets",
            onClick = onExplore
        )
        Spacer(Modifier.height(12.dp))
        SecondaryActionCard(
            title = "Gallery",
            subtitle = "Open saved projects",
            onClick = onGallery
        )

        Spacer(Modifier.height(32.dp))
        Text(
            text = "Offline-first  ·  Seeded  ·  CPU rendering",
            style = MaterialTheme.typography.labelMedium,
            color = MidGray
        )
    }
}

@Composable
private fun PrimaryActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Graphite)
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.titleLarge, color = PureWhite, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = SoftGray)
        }
    }
}

@Composable
private fun SecondaryActionCard(title: String, subtitle: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Charcoal)
            .clickable(onClick = onClick)
            .padding(18.dp)
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, color = OffWhite)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = SoftGray)
        }
    }
}
