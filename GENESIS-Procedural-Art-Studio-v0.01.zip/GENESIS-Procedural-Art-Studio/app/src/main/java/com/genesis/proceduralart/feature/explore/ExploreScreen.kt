package com.genesis.proceduralart.feature.explore

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.ui.theme.*

@Composable
fun ExploreScreen(onOpenGenerator: (String) -> Unit) {
    // Always ensure registry is ready (safe if already initialized)
    val generators = remember {
        GeneratorBootstrap.ensureInitialized()
        GeneratorRegistry.all()
    }
    val categories = remember(generators) {
        generators.map { it.category }.distinct()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
    ) {
        Text("Explore", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text(
            "${generators.size} generators available offline",
            style = MaterialTheme.typography.bodyMedium,
            color = SoftGray,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            categories.forEach { category ->
                item {
                    Text(
                        category.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MidGray,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                items(generators.filter { it.category == category }, key = { it.id }) { gen ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Charcoal, shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                            .clickable { onOpenGenerator(gen.id) }
                            .padding(16.dp)
                    ) {
                        Text(gen.name, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                        Text(
                            gen.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = SoftGray,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
