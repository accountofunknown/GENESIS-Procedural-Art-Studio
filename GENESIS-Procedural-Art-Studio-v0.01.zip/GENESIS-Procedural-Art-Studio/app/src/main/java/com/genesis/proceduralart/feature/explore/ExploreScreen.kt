package com.genesis.proceduralart.feature.explore

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap
import com.genesis.proceduralart.core.algorithm.GeneratorRegistry
import com.genesis.proceduralart.ui.theme.*

@Composable
fun ExploreScreen(onOpenGenerator: (String) -> Unit) {
    LaunchedEffect(Unit) { GeneratorBootstrap.ensureInitialized() }
    val generators = remember { GeneratorRegistry.all() }
    val categories = remember { GeneratorRegistry.categories() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
    ) {
        Text("Explore", style = MaterialTheme.typography.headlineMedium, color = PureWhite)
        Text(
            "${generators.size} generators available offline",
            style = MaterialTheme.typography.bodyMedium,
            color = SoftGray
        )
        Spacer(Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            categories.forEach { category ->
                item {
                    Text(
                        category.uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MidGray,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                items(generators.filter { it.category == category }, key = { it.id }) { gen ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Charcoal)
                            .clickable { onOpenGenerator(gen.id) }
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(gen.name, style = MaterialTheme.typography.titleMedium, color = OffWhite)
                            Spacer(Modifier.height(2.dp))
                            Text(gen.description, style = MaterialTheme.typography.bodyMedium, color = SoftGray)
                        }
                    }
                }
            }
        }
    }
}
