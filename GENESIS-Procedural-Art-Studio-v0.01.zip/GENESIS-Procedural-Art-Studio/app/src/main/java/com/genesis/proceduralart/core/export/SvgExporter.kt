package com.genesis.proceduralart.core.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Exports a rendered bitmap as an SVG that embeds the PNG.
 * MediaStore.Files only allows Download/Documents as primary directories (not Pictures),
 * so SVG is saved under Download/GENESIS.
 */
class SvgExporter(private val context: Context) {

    suspend fun saveSvg(
        bitmap: Bitmap,
        fileName: String,
        generatorName: String = "GENESIS",
        seed: Long = 0L
    ): ExportResult = withContext(Dispatchers.IO) {
        try {
            val pngBytes = ByteArrayOutputStream().use { baos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                baos.toByteArray()
            }
            val b64 = Base64.encodeToString(pngBytes, Base64.NO_WRAP)
            val w = bitmap.width
            val h = bitmap.height
            val displayName = if (fileName.endsWith(".svg", ignoreCase = true)) fileName else "$fileName.svg"

            val svg = buildString {
                appendLine("""<?xml version="1.0" encoding="UTF-8"?>""")
                appendLine("""<!-- GENESIS Procedural Art Studio · $generatorName · seed=$seed -->""")
                appendLine("""<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"""")
                appendLine("""     width="$w" height="$h" viewBox="0 0 $w $h">""")
                appendLine("""  <title>$generatorName</title>""")
                appendLine("""  <rect width="100%" height="100%" fill="#000000"/>""")
                appendLine("""  <image width="$w" height="$h" xlink:href="data:image/png;base64,$b64"/>""")
                appendLine("""</svg>""")
            }
            val bytes = svg.toByteArray(Charsets.UTF_8)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/svg+xml")
                    // Files collection: only Download / Documents are allowed primary dirs
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/GENESIS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val resolver = context.contentResolver
                val uri = resolver.insert(collection, values)
                    ?: return@withContext ExportResult(false, error = "Could not create MediaStore entry for SVG")
                try {
                    resolver.openOutputStream(uri)?.use { out -> out.write(bytes) }
                        ?: run {
                            resolver.delete(uri, null, null)
                            return@withContext ExportResult(false, error = "Could not open SVG output stream")
                        }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    ExportResult(success = true, uri = uri, pathHint = "Download/GENESIS/$displayName")
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                // Pre-Q: write into public Downloads/GENESIS
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "GENESIS"
                )
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, displayName)
                FileOutputStream(file).use { it.write(bytes) }
                ExportResult(
                    success = true,
                    uri = android.net.Uri.fromFile(file),
                    pathHint = "Download/GENESIS/$displayName"
                )
            }
        } catch (e: Exception) {
            ExportResult(false, error = e.message ?: "SVG export failed")
        }
    }
}
