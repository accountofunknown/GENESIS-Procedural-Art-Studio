package com.genesis.proceduralart.core.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * Exports a rendered bitmap as an SVG that embeds the PNG (universal, resolution-independent container).
 * True path-only SVG for every generator is deferred; this still gives a valid .svg file users can open.
 */
class SvgExporter(private val context: Context) {

    suspend fun saveSvg(
        bitmap: Bitmap,
        fileName: String,
        generatorName: String = "GENESIS",
        seed: Long = 0L
    ): ExportResult = withContext(Dispatchers.IO) {
        try {
            val pngBytes = ByteArrayOutputStream().use { baos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                baos.toByteArray()
            }
            val b64 = Base64.encodeToString(pngBytes, Base64.NO_WRAP)
            val w = bitmap.width
            val h = bitmap.height
            val displayName = if (fileName.endsWith(".svg", ignoreCase = true)) fileName else "$fileName.svg"

            val svg = buildString {
                appendLine("""<?xml version="1.0" encoding="UTF-8"?>""")
                appendLine("""<!-- GENESIS Procedural Art Studio · $generatorName · seed=$seed -->""")
                appendLine("""<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"""")
                appendLine("""     width="$w" height="$h" viewBox="0 0 $w $h">""")
                appendLine("""  <title>$generatorName</title>""")
                appendLine("""  <rect width="100%" height="100%" fill="#000000"/>""")
                appendLine("""  <image width="$w" height="$h" xlink:href="data:image/png;base64,$b64"/>""")
                appendLine("""</svg>""")
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/svg+xml")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GENESIS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Files.getContentUri("external")
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(collection, values)
                ?: return@withContext ExportResult(false, error = "Could not create MediaStore entry for SVG")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(svg.toByteArray(Charsets.UTF_8))
            } ?: run {
                resolver.delete(uri, null, null)
                return@withContext ExportResult(false, error = "Could not open SVG output stream")
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }

            ExportResult(success = true, uri = uri, pathHint = "Pictures/GENESIS/$displayName")
        } catch (e: Exception) {
            ExportResult(false, error = e.message ?: "SVG export failed")
        }
    }
}
