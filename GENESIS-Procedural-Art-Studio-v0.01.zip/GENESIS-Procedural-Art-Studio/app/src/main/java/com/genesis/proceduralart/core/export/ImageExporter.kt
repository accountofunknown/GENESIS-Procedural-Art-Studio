package com.genesis.proceduralart.core.export

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class ExportResult(
    val success: Boolean,
    val uri: Uri? = null,
    val pathHint: String? = null,
    val error: String? = null
)

class ImageExporter(private val context: Context) {

    /**
     * Save bitmap as PNG or JPEG into the public Pictures/GENESIS folder via MediaStore
     * (no broad storage permission needed on modern Android).
     */
    suspend fun saveToGallery(
        bitmap: Bitmap,
        fileName: String,
        format: String = "PNG", // PNG or JPEG
        quality: Int = 95
    ): ExportResult = withContext(Dispatchers.IO) {
        try {
            val mime = if (format.equals("JPEG", ignoreCase = true)) "image/jpeg" else "image/png"
            val displayName = if (fileName.contains('.')) fileName else {
                if (format.equals("JPEG", ignoreCase = true)) "$fileName.jpg" else "$fileName.png"
            }

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GENESIS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(collection, values)
                ?: return@withContext ExportResult(false, error = "Could not create MediaStore entry")

            resolver.openOutputStream(uri)?.use { out ->
                val ok = if (format.equals("JPEG", ignoreCase = true)) {
                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(50, 100), out)
                } else {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                if (!ok) {
                    resolver.delete(uri, null, null)
                    return@withContext ExportResult(false, error = "Compress failed")
                }
            } ?: return@withContext ExportResult(false, error = "Could not open output stream")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }

            ExportResult(success = true, uri = uri, pathHint = "Pictures/GENESIS/$displayName")
        } catch (e: Exception) {
            ExportResult(success = false, error = e.message ?: "Export failed")
        }
    }

    /**
     * Write to cache and return a shareable content URI (for Sharesheet).
     */
    suspend fun prepareShareUri(
        bitmap: Bitmap,
        fileName: String = "genesis_share.png"
    ): ExportResult = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.cacheDir, "shared").also { it.mkdirs() }
            val file = File(dir, fileName)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            ExportResult(success = true, uri = uri, pathHint = file.absolutePath)
        } catch (e: Exception) {
            ExportResult(success = false, error = e.message ?: "Share prepare failed")
        }
    }

    fun createShareIntent(uri: Uri): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
