package com.genesis.proceduralart

import android.app.Application
import com.genesis.proceduralart.core.algorithm.GeneratorBootstrap

class GenesisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Register all procedural generators before any screen reads the registry
        GeneratorBootstrap.ensureInitialized()
    }
}
