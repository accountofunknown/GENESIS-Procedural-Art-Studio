package com.genesis.proceduralart

import android.app.Application

class GenesisApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Future: initialize any global singletons that do not require Activity context
    }
}
