package com.genesis.proceduralart

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.genesis.proceduralart.ui.theme.GenesisTheme
import com.genesis.proceduralart.ui.GenesisApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GenesisTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GenesisApp()
                }
            }
        }
    }
}
