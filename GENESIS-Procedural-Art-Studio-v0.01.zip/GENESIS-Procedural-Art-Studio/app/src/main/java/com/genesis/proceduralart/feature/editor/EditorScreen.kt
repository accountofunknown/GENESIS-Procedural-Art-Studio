package com.genesis.proceduralart.feature.editor

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.ui.theme.*

@Composable
fun EditorScreen(
    projectIdToLoad: String? = null,
    initialGeneratorId: String? = null,
    vm: EditorViewModel = viewModel()
) {
    val state by vm.ui.collectAsState()
    val config = LocalConfiguration.current
    // Keep a solid preview band on phones (about 38% of screen, min 220dp)
    val previewHeight = (config.screenHeightDp * 0.38f).dp.coerceAtLeast(220.dp)

    LaunchedEffect(projectIdToLoad, initialGeneratorId) {
        when {
            projectIdToLoad != null -> vm.loadProject(projectIdToLoad)
            initialGeneratorId != null -> vm.selectGenerator(initialGeneratorId)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        // Fixed-height preview so it cannot collapse on small screens
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(previewHeight)
                .background(NearBlack)
                .padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(PureBlack)
                    .border(1.dp, DarkGray, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                when {
                    state.preview != null -> {
                        Image(
                            bitmap = state.preview!!.asImageBitmap(),
                            contentDescription = "Artwork preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(4.dp),
                            contentScale = ContentScale.Fit
                        )
                    }
                    state.isRendering -> {
                        CircularProgressIndicator(color = PureWhite)
                    }
                    else -> {
                        Text("Preview will appear here", color = SoftGray)
                    }
                }
            }

            if (state.isRendering || state.isBusy) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    color = PureWhite,
                    trackColor = DarkGray
                )
            }
        }

        // Scrollable controls below preview
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Charcoal)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { vm.saveProject() },
                    enabled = !state.isBusy && !state.isRendering,
                    colors = ButtonDefaults.buttonColors(containerColor = Graphite, contentColor = PureWhite),
                    modifier = Modifier.weight(1f)
                ) { Text("Save") }
                Button(
                    onClick = { vm.exportPng() },
                    enabled = !state.isBusy && !state.isRendering,
                    colors = ButtonDefaults.buttonColors(containerColor = Graphite, contentColor = PureWhite),
                    modifier = Modifier.weight(1f)
                ) { Text("PNG") }
                Button(
                    onClick = { vm.exportJpeg() },
                    enabled = !state.isBusy && !state.isRendering,
                    colors = ButtonDefaults.buttonColors(containerColor = Graphite, contentColor = PureWhite),
                    modifier = Modifier.weight(1f)
                ) { Text("JPEG") }
                Button(
                    onClick = { vm.exportSvg() },
                    enabled = !state.isBusy && !state.isRendering,
                    colors = ButtonDefaults.buttonColors(containerColor = Graphite, contentColor = PureWhite),
                    modifier = Modifier.weight(1f)
                ) { Text("SVG") }
            }

            state.statusMessage?.let {
                Text(it, style = MaterialTheme.typography.labelMedium, color = OffWhite, modifier = Modifier.padding(top = 6.dp))
            }
            state.lastError?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 4.dp))
            }

            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = state.projectName,
                onValueChange = { vm.setProjectName(it) },
                label = { Text("Project name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = OffWhite,
                    focusedBorderColor = SoftGray,
                    unfocusedBorderColor = MidGray,
                    focusedLabelColor = SoftGray,
                    unfocusedLabelColor = MidGray
                )
            )

            Spacer(Modifier.height(12.dp))
            Text("Generator", style = MaterialTheme.typography.labelMedium, color = SoftGray)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                state.generators.forEach { gen ->
                    val selected = gen.id == state.selectedGeneratorId
                    FilterChip(
                        selected = selected,
                        onClick = { vm.selectGenerator(gen.id) },
                        label = { Text(gen.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PureWhite,
                            selectedLabelColor = PureBlack,
                            containerColor = Graphite,
                            labelColor = OffWhite
                        ),
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Seed", style = MaterialTheme.typography.labelMedium, color = SoftGray, modifier = Modifier.width(48.dp))
                OutlinedTextField(
                    value = state.seed.toString(),
                    onValueChange = { t -> t.toLongOrNull()?.let { vm.setSeed(it) } },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = PureWhite,
                        unfocusedTextColor = OffWhite,
                        focusedBorderColor = SoftGray,
                        unfocusedBorderColor = MidGray
                    )
                )
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { vm.randomizeSeed() }) {
                    Text("Random", color = PureWhite)
                }
            }

            Spacer(Modifier.height(8.dp))
            Row {
                TextButton(onClick = { vm.randomizeParameters() }) {
                    Text("Randomize Params", color = PureWhite)
                }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { vm.requestPreview() }) {
                    Text("Regenerate", color = PureWhite)
                }
            }

            if (state.renderMs > 0) {
                Text(
                    "${state.renderMs} ms  ·  CPU  ·  Export ${state.exportWidth}×${state.exportHeight}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MidGray
                )
            }

            Spacer(Modifier.height(8.dp))
            Text("Export size", style = MaterialTheme.typography.labelMedium, color = SoftGray)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(512, 1080, 2048).forEach { size ->
                    val selected = state.exportWidth == size
                    FilterChip(
                        selected = selected,
                        onClick = { vm.setExportSize(size) },
                        label = { Text("${size}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PureWhite,
                            selectedLabelColor = PureBlack,
                            containerColor = Graphite,
                            labelColor = SoftGray
                        )
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Text("Color mode", style = MaterialTheme.typography.labelMedium, color = SoftGray)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    0 to "Mono",
                    1 to "Spectrum",
                    2 to "Heat",
                    3 to "Neon",
                    4 to "Ocean",
                    5 to "Forest",
                    6 to "Sunset",
                    7 to "Ice",
                    8 to "Custom"
                ).forEach { (mode, label) ->
                    val selected = state.colorMode == mode
                    FilterChip(
                        selected = selected,
                        onClick = { vm.setColorMode(mode) },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PureWhite,
                            selectedLabelColor = PureBlack,
                            containerColor = Graphite,
                            labelColor = SoftGray
                        )
                    )
                }
            }
            if (state.colorMode > 0) {
                if (state.colorMode != 8) {
                    Text(
                        "Hue shift: ${"%.0f".format(state.hueShift)}°",
                        style = MaterialTheme.typography.labelMedium,
                        color = SoftGray
                    )
                    Slider(
                        value = state.hueShift,
                        onValueChange = { vm.setHueShift(it) },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(
                            thumbColor = PureWhite,
                            activeTrackColor = SoftGray,
                            inactiveTrackColor = DarkGray
                        )
                    )
                }
                Text(
                    "Saturation: ${"%.2f".format(state.colorSaturation)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SoftGray
                )
                Slider(
                    value = state.colorSaturation,
                    onValueChange = { vm.setColorSaturation(it) },
                    valueRange = 0f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = PureWhite,
                        activeTrackColor = SoftGray,
                        inactiveTrackColor = DarkGray
                    )
                )
                Text(
                    "Brightness: ${"%.2f".format(state.colorBrightness)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SoftGray
                )
                Slider(
                    value = state.colorBrightness,
                    onValueChange = { vm.setColorBrightness(it) },
                    valueRange = 0.3f..1.8f,
                    colors = SliderDefaults.colors(
                        thumbColor = PureWhite,
                        activeTrackColor = SoftGray,
                        inactiveTrackColor = DarkGray
                    )
                )
            }
            if (state.colorMode == 8) {
                Spacer(Modifier.height(6.dp))
                Text("Multi-colour stops (dark → bright)", style = MaterialTheme.typography.labelMedium, color = SoftGray)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    state.customColors.forEachIndexed { index, col ->
                        val selected = state.selectedColorSlot == index
                        Box(
                            modifier = Modifier
                                .size(if (selected) 40.dp else 32.dp)
                                .border(
                                    width = if (selected) 2.dp else 1.dp,
                                    color = if (selected) PureWhite else SoftGray,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .background(ComposeColor(col), RoundedCornerShape(8.dp))
                                .clickable { vm.selectColorSlot(index) }
                        )
                    }
                    TextButton(onClick = { vm.addCustomColorSlot() }) {
                        Text("+", color = PureWhite)
                    }
                    if (state.customColors.size > 2) {
                        TextButton(onClick = { vm.removeCustomColorSlot() }) {
                            Text("−", color = PureWhite)
                        }
                    }
                }
                // HSV editor for selected slot
                val slot = state.customColors.getOrNull(state.selectedColorSlot)
                if (slot != null) {
                    val hsv = remember(slot) {
                        val arr = FloatArray(3)
                        android.graphics.Color.colorToHSV(slot, arr)
                        arr
                    }
                    var h by remember(slot) { mutableStateOf(hsv[0]) }
                    var s by remember(slot) { mutableStateOf(hsv[1]) }
                    var v by remember(slot) { mutableStateOf(hsv[2]) }
                    Text("Edit stop ${state.selectedColorSlot + 1}", style = MaterialTheme.typography.labelMedium, color = SoftGray)
                    Text("Hue: ${"%.0f".format(h)}°", style = MaterialTheme.typography.labelSmall, color = MidGray)
                    Slider(
                        value = h,
                        onValueChange = {
                            h = it
                            vm.setCustomColorHsv(h, s, v)
                        },
                        valueRange = 0f..360f,
                        colors = SliderDefaults.colors(thumbColor = PureWhite, activeTrackColor = SoftGray, inactiveTrackColor = DarkGray)
                    )
                    Text("Sat: ${"%.2f".format(s)}", style = MaterialTheme.typography.labelSmall, color = MidGray)
                    Slider(
                        value = s,
                        onValueChange = {
                            s = it
                            vm.setCustomColorHsv(h, s, v)
                        },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = PureWhite, activeTrackColor = SoftGray, inactiveTrackColor = DarkGray)
                    )
                    Text("Value: ${"%.2f".format(v)}", style = MaterialTheme.typography.labelSmall, color = MidGray)
                    Slider(
                        value = v,
                        onValueChange = {
                            v = it
                            vm.setCustomColorHsv(h, s, v)
                        },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = PureWhite, activeTrackColor = SoftGray, inactiveTrackColor = DarkGray)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text("Presets", style = MaterialTheme.typography.labelMedium, color = SoftGray)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    com.genesis.proceduralart.core.color.Colorize.presetPalettes.forEachIndexed { index, pair ->
                        FilterChip(
                            selected = false,
                            onClick = { vm.applyPresetPalette(index) },
                            label = { Text(pair.first) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Graphite,
                                labelColor = SoftGray
                            )
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            val gen = state.generators.find { it.id == state.selectedGeneratorId }
            gen?.parameterSchema?.forEach { def ->
                when (def.type) {
                    ParameterType.FLOAT, ParameterType.INT -> {
                        val current = state.parameters.values[def.key] ?: def.defaultValue
                        val min = def.min ?: 0f
                        val max = def.max ?: 1f
                        val value = current.toFloatOrNull() ?: min
                        Text(
                            "${def.label}: ${"%.2f".format(value)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = SoftGray
                        )
                        Slider(
                            value = value.coerceIn(min, max),
                            onValueChange = { v ->
                                val s = if (def.type == ParameterType.INT) v.toInt().toString() else "%.3f".format(v)
                                vm.updateParam(def.key, s)
                            },
                            valueRange = min..max,
                            colors = SliderDefaults.colors(
                                thumbColor = PureWhite,
                                activeTrackColor = SoftGray,
                                inactiveTrackColor = DarkGray
                            )
                        )
                    }
                    else -> {}
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
