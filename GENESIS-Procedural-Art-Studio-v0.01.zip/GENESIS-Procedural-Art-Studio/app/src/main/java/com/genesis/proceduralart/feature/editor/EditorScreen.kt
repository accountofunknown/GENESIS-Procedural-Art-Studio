package com.genesis.proceduralart.feature.editor

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.genesis.proceduralart.core.model.ParameterType
import com.genesis.proceduralart.ui.theme.*

@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val state by vm.ui.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
    ) {
        // Preview area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(NearBlack),
            contentAlignment = Alignment.Center
        ) {
            if (state.preview != null) {
                Image(
                    bitmap = state.preview!!.asImageBitmap(),
                    contentDescription = "Artwork preview",
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    contentScale = ContentScale.Fit
                )
            } else if (state.isRendering) {
                CircularProgressIndicator(color = PureWhite)
            } else {
                Text("Select a generator", color = SoftGray)
            }
            if (state.isRendering) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(8.dp),
                    color = PureWhite,
                    trackColor = DarkGray
                )
            }
        }

        // Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Charcoal)
                .verticalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            // Generator chips
            Text("Generator", style = MaterialTheme.typography.labelMedium, color = SoftGray)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                state.generators.forEach { gen ->
                    val selected = gen.id == state.selectedGeneratorId
                    FilterChip(
                        selected = selected,
                        onClick = { vm.selectGenerator(gen.id) },
                        label = { Text(gen.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PureWhite,
                            selectedLabelColor = PureBlack,
                            containerColor = Graphite,
                            labelColor = OffWhite
                        ),
                        modifier = Modifier.padding(end = 6.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            // Seed
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Seed", style = MaterialTheme.typography.labelMedium, color = SoftGray, modifier = Modifier.width(48.dp))
                OutlinedTextField(
                    value = state.seed.toString(),
                    onValueChange = { t -> t.toLongOrNull()?.let { vm.setSeed(it) } },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = PureWhite,
                        unfocusedTextColor = OffWhite,
                        focusedBorderColor = SoftGray,
                        unfocusedBorderColor = MidGray
                    )
                )
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { vm.randomizeSeed() }) {
                    Text("Random", color = PureWhite)
                }
            }

            Spacer(Modifier.height(8.dp))
            Row {
                TextButton(onClick = { vm.randomizeParameters() }) {
                    Text("Randomize Params", color = PureWhite)
                }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { vm.requestPreview() }) {
                    Text("Regenerate", color = PureWhite)
                }
            }

            if (state.renderMs > 0) {
                Text("${state.renderMs} ms  ·  CPU", style = MaterialTheme.typography.labelSmall, color = MidGray)
            }
            state.lastError?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(12.dp))
            val gen = state.generators.find { it.id == state.selectedGeneratorId }
            gen?.parameterSchema?.forEach { def ->
                when (def.type) {
                    ParameterType.FLOAT, ParameterType.INT -> {
                        val current = state.parameters.values[def.key] ?: def.defaultValue
                        val min = def.min ?: 0f
                        val max = def.max ?: 1f
                        val value = current.toFloatOrNull() ?: min
                        Text("${def.label}: ${"%.2f".format(value)}", style = MaterialTheme.typography.labelMedium, color = SoftGray)
                        Slider(
                            value = value.coerceIn(min, max),
                            onValueChange = { v ->
                                val s = if (def.type == ParameterType.INT) v.toInt().toString() else "%.3f".format(v)
                                vm.updateParam(def.key, s)
                            },
                            valueRange = min..max,
                            colors = SliderDefaults.colors(
                                thumbColor = PureWhite,
                                activeTrackColor = SoftGray,
                                inactiveTrackColor = DarkGray
                            )
                        )
                    }
                    else -> {}
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
